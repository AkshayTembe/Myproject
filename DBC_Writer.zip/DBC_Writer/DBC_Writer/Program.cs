﻿using ExcelParserLib;
using DbcParserLib;  // <- optional only if you call DbcWriter directly

class Program
{
    static void Main()
    {
        var excelParser = new ExcelParser();
        var result = excelParser.Parse("C:\\Users\\HP\\Downloads\\DbcParser-main\\DbcParser-main\\DbcFiles\\tesla_can1_converted.xlsx");

        foreach (var w in result.Warnings)
            Console.WriteLine("Warning: " + w);

        // Use DbcWriter (still defined in DbcParserLib)
        DbcWriter.WriteToPath("C:\\Users\\HP\\Downloads\\DbcParser-main\\DbcParser-main\\DbcFiles\\output.dbc", result.Dbc);
    }
}
