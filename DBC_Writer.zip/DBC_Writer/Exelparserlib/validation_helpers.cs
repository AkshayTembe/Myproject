// ValidationHelpers.cs
using System;
using System.Linq;
using DbcParserLib.Model;

namespace DbcParserLib.Excel.Helpers
{
    /// <summary>
    /// Validation utilities for Excel data
    /// </summary>
    public static class ValidationHelpers
    {
        /// <summary>
        /// Validates a DBC identifier (node name, message name, signal name, etc.)
        /// Must start with letter or underscore, followed by alphanumeric or underscore
        /// </summary>
        public static bool IsValidDbcIdentifier(string identifier)
        {
            if (string.IsNullOrWhiteSpace(identifier))
                return false;

            identifier = identifier.Trim();

            // Must start with letter or underscore
            if (!char.IsLetter(identifier[0]) && identifier[0] != '_')
                return false;

            // Rest must be alphanumeric or underscore
            for (int i = 1; i < identifier.Length; i++)
            {
                if (!char.IsLetterOrDigit(identifier[i]) && identifier[i] != '_')
                    return false;
            }

            return true;
        }

        /// <summary>
        /// Validates a message ID (must be within valid CAN ID range)
        /// Standard CAN: 0-0x7FF (2047)
        /// Extended CAN: 0-0x1FFFFFFF (536870911)
        /// </summary>
        public static bool IsValidMessageId(uint messageId, bool isExtended)
        {
            if (isExtended)
            {
                // Extended CAN ID: 29-bit (0 to 0x1FFFFFFF)
                return messageId <= 0x1FFFFFFF;
            }
            else
            {
                // Standard CAN ID: 11-bit (0 to 0x7FF)
                return messageId <= 0x7FF;
            }
        }

        /// <summary>
        /// Validates a DLC (Data Length Code) value
        /// Must be 0-8 for standard CAN, 0-64 for CAN FD
        /// </summary>
        public static bool IsValidDlc(ushort dlc, bool isCanFd = false)
        {
            if (isCanFd)
            {
                // CAN FD allows up to 64 bytes
                return dlc <= 64;
            }
            else
            {
                // Standard CAN allows up to 8 bytes
                return dlc <= 8;
            }
        }

        /// <summary>
        /// Validates signal start bit and length
        /// Must fit within the message DLC
        /// </summary>
        public static bool IsValidSignalBitPosition(ushort startBit, ushort length, ushort messageDlc)
        {
            if (length == 0 || length > 64)
                return false;

            // For little endian (Intel), simple check
            // For big endian (Motorola), more complex - but we do basic check here
            int totalBits = messageDlc * 8;
            
            // Basic check: start bit must be within message bounds
            if (startBit >= totalBits)
                return false;

            // Check if signal fits (simplified - doesn't account for Motorola byte order complexity)
            return (startBit + length) <= totalBits || startBit < totalBits;
        }

        /// <summary>
        /// Validates byte order (0 = Motorola/MSB, 1 = Intel/LSB)
        /// </summary>
        public static bool IsValidByteOrder(byte byteOrder)
        {
            return byteOrder == 0 || byteOrder == 1;
        }

        /// <summary>
        /// Validates property scope string
        /// Valid scopes: GLOBAL, NODE, MESSAGE, SIGNAL, ENV
        /// </summary>
        public static bool TryParsePropertyScope(string scope, out CustomPropertyObjectType objectType)
        {
            objectType = CustomPropertyObjectType.Global;

            if (string.IsNullOrWhiteSpace(scope))
                return false;

            scope = scope.Trim().ToUpperInvariant();

            switch (scope)
            {
                case "GLOBAL":
                    objectType = CustomPropertyObjectType.Global;
                    return true;
                case "NODE":
                case "BU":
                case "BU_":
                    objectType = CustomPropertyObjectType.Node;
                    return true;
                case "MESSAGE":
                case "BO":
                case "BO_":
                    objectType = CustomPropertyObjectType.Message;
                    return true;
                case "SIGNAL":
                case "SG":
                case "SG_":
                    objectType = CustomPropertyObjectType.Signal;
                    return true;
                case "ENV":
                case "ENVIRONMENT":
                case "EV":
                case "EV_":
                    objectType = CustomPropertyObjectType.Environment;
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Validates property data type string
        /// Valid types: INT, HEX, FLOAT, STRING, ENUM
        /// </summary>
        public static bool TryParsePropertyDataType(string type, out CustomPropertyDataType dataType)
        {
            dataType = CustomPropertyDataType.Integer;

            if (string.IsNullOrWhiteSpace(type))
                return false;

            type = type.Trim().ToUpperInvariant();

            switch (type)
            {
                case "INT":
                case "INTEGER":
                    dataType = CustomPropertyDataType.Integer;
                    return true;
                case "HEX":
                case "HEXADECIMAL":
                    dataType = CustomPropertyDataType.Hex;
                    return true;
                case "FLOAT":
                case "DOUBLE":
                case "REAL":
                    dataType = CustomPropertyDataType.Float;
                    return true;
                case "STRING":
                case "STR":
                    dataType = CustomPropertyDataType.String;
                    return true;
                case "ENUM":
                case "ENUMERATION":
                    dataType = CustomPropertyDataType.Enum;
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Validates environment variable type string
        /// Valid types: INT, FLOAT, STRING, DATA
        /// </summary>
        public static bool TryParseEnvVarType(string type, out EnvDataType envType)
        {
            envType = EnvDataType.Integer;

            if (string.IsNullOrWhiteSpace(type))
                return false;

            type = type.Trim().ToUpperInvariant();

            switch (type)
            {
                case "INT":
                case "INTEGER":
                case "0":
                    envType = EnvDataType.Integer;
                    return true;
                case "FLOAT":
                case "DOUBLE":
                case "1":
                    envType = EnvDataType.Float;
                    return true;
                case "STRING":
                case "STR":
                case "2":
                    envType = EnvDataType.String;
                    return true;
                case "DATA":
                    envType = EnvDataType.Data;
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Validates comment type string
        /// Valid types: BO, SG, BU, EV
        /// </summary>
        public static bool IsValidCommentType(string type)
        {
            if (string.IsNullOrWhiteSpace(type))
                return false;

            type = type.Trim().ToUpperInvariant();

            return type == "BO" || type == "SG" || type == "BU" || type == "EV" ||
                   type == "MESSAGE" || type == "SIGNAL" || type == "NODE" || type == "ENVIRONMENT";
        }

        /// <summary>
        /// Normalizes comment type to standard format (BO, SG, BU, EV)
        /// </summary>
        public static string NormalizeCommentType(string type)
        {
            if (string.IsNullOrWhiteSpace(type))
                return null;

            type = type.Trim().ToUpperInvariant();

            switch (type)
            {
                case "BO":
                case "MESSAGE":
                    return "BO";
                case "SG":
                case "SIGNAL":
                    return "SG";
                case "BU":
                case "NODE":
                    return "BU";
                case "EV":
                case "ENVIRONMENT":
                    return "EV";
                default:
                    return null;
            }
        }

        /// <summary>
        /// Validates that a signal value type is valid
        /// Valid types: Signed, Unsigned, IEEEFloat, IEEEDouble
        /// </summary>
        public static bool TryParseSignalValueType(string type, out DbcValueType valueType)
        {
            valueType = DbcValueType.Signed;

            if (string.IsNullOrWhiteSpace(type))
            {
                // Default to signed if not specified
                return true;
            }

            type = type.Trim().ToUpperInvariant();

            switch (type)
            {
                case "SIGNED":
                case "SIGN":
                case "-":
                case "1":
                    valueType = DbcValueType.Signed;
                    return true;
                case "UNSIGNED":
                case "UNSIGN":
                case "+":
                case "0":
                    valueType = DbcValueType.Unsigned;
                    return true;
                case "FLOAT":
                case "IEEEFLOAT":
                case "IEEE_FLOAT":
                case "2":
                    valueType = DbcValueType.IEEEFloat;
                    return true;
                case "DOUBLE":
                case "IEEEDOUBLE":
                case "IEEE_DOUBLE":
                case "3":
                    valueType = DbcValueType.IEEEDouble;
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Validates receiver list string (comma-separated node names)
        /// </summary>
        public static bool IsValidReceiverList(string receivers)
        {
            if (string.IsNullOrWhiteSpace(receivers))
                return true; // Empty is valid

            var names = receivers.Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);

            return names.All(name => IsValidDbcIdentifier(name.Trim()));
        }

        /// <summary>
        /// Parses receiver list into array of node names
        /// </summary>
        public static string[] ParseReceiverList(string receivers)
        {
            if (string.IsNullOrWhiteSpace(receivers))
                return new string[0];

            return receivers.Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries)
                           .Select(s => s.Trim())
                           .Where(s => !string.IsNullOrEmpty(s))
                           .ToArray();
        }

        /// <summary>
        /// Validates enum values string format
        /// Expected format: "Value1","Value2","Value3" or Value1,Value2,Value3
        /// </summary>
        public static bool TryParseEnumValues(string enumValuesStr, out string[] enumValues)
        {
            enumValues = null;

            if (string.IsNullOrWhiteSpace(enumValuesStr))
                return false;

            try
            {
                // Handle both quoted and unquoted formats
                var values = enumValuesStr.Split(',')
                    .Select(v => v.Trim().Trim('"', ' '))
                    .Where(v => !string.IsNullOrEmpty(v))
                    .ToArray();

                if (values.Length == 0)
                    return false;

                enumValues = values;
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
