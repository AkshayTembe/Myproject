// SimpleExcelObserver.cs
using System.Collections.Generic;

namespace DbcParserLib.Excel.Observers
{
    /// <summary>
    /// Simple implementation of IExcelParseFailureObserver that collects all errors into a list
    /// Useful for debugging and displaying errors to users
    /// </summary>
    public class SimpleExcelObserver : IExcelParseFailureObserver
    {
        private readonly IList<string> m_errors = new List<string>();
        private readonly IList<string> m_warnings = new List<string>();

        public string CurrentSheet { get; set; }
        public int CurrentRow { get; set; }

        private void AddError(string error)
        {
            var location = string.IsNullOrEmpty(CurrentSheet) 
                ? $"Row {CurrentRow}" 
                : $"Sheet '{CurrentSheet}', Row {CurrentRow}";
            m_errors.Add($"[{location}] {error}");
        }

        private void AddWarning(string warning)
        {
            var location = string.IsNullOrEmpty(CurrentSheet) 
                ? $"Row {CurrentRow}" 
                : $"Sheet '{CurrentSheet}', Row {CurrentRow}";
            m_warnings.Add($"[{location}] {warning}");
        }

        // Sheet structure errors
        public void SheetNotFound(string sheetName)
        {
            m_errors.Add($"Sheet '{sheetName}' not found in workbook");
        }

        public void SheetHeaderMissing(string sheetName, string expectedHeader)
        {
            m_errors.Add($"Sheet '{sheetName}' missing required header column '{expectedHeader}'");
        }

        public void SheetEmpty(string sheetName)
        {
            AddWarning($"Sheet '{sheetName}' is empty");
        }

        // Data validation errors
        public void InvalidHexId(string value)
        {
            AddError($"Invalid hex ID format: '{value}'");
        }

        public void InvalidInteger(string fieldName, string value)
        {
            AddError($"Invalid integer value for '{fieldName}': '{value}'");
        }

        public void InvalidFloat(string fieldName, string value)
        {
            AddError($"Invalid float value for '{fieldName}': '{value}'");
        }

        public void InvalidBoolean(string fieldName, string value)
        {
            AddError($"Invalid boolean value for '{fieldName}': '{value}'");
        }

        public void InvalidEnum(string fieldName, string value, string[] validValues)
        {
            AddError($"Invalid enum value for '{fieldName}': '{value}'. Valid values: {string.Join(", ", validValues)}");
        }

        public void MissingRequiredField(string fieldName)
        {
            AddError($"Missing required field: '{fieldName}'");
        }

        // Value table parsing errors
        public void ValueTableFormatError(string valueTableString)
        {
            AddError($"Value table format error: '{valueTableString}'");
        }

        public void ValueTableDuplicate(string tableName)
        {
            AddError($"Duplicate value table: '{tableName}'");
        }

        // Node errors
        public void NodeNameInvalid(string nodeName)
        {
            AddError($"Invalid node name: '{nodeName}'");
        }

        public void DuplicatedNode(string nodeName)
        {
            AddError($"Duplicated node: '{nodeName}'");
        }

        // Message errors
        public void MessageIdInvalid(string messageId)
        {
            AddError($"Invalid message ID: '{messageId}'");
        }

        public void MessageNameInvalid(string messageName)
        {
            AddError($"Invalid message name: '{messageName}'");
        }

        public void DuplicatedMessage(string messageId)
        {
            AddError($"Duplicated message ID: '{messageId}'");
        }

        public void MessageNotFound(string messageId)
        {
            AddError($"Message not found: '{messageId}'");
        }

        // Signal errors
        public void SignalNameInvalid(string signalName)
        {
            AddError($"Invalid signal name: '{signalName}'");
        }

        public void DuplicatedSignalInMessage(string messageId, string signalName)
        {
            AddError($"Duplicated signal '{signalName}' in message '{messageId}'");
        }

        public void SignalFormatError(string fieldName, string value)
        {
            AddError($"Signal format error in '{fieldName}': '{value}'");
        }

        public void SignalMessageNotFound(string messageId, string signalName)
        {
            AddError($"Message '{messageId}' not found for signal '{signalName}'");
        }

        // Environment variable errors
        public void EnvironmentVariableNameInvalid(string name)
        {
            AddError($"Invalid environment variable name: '{name}'");
        }

        public void DuplicatedEnvironmentVariable(string name)
        {
            AddError($"Duplicated environment variable: '{name}'");
        }

        public void EnvironmentVariableNotFound(string name)
        {
            AddError($"Environment variable not found: '{name}'");
        }

        // Custom property errors
        public void PropertyDefinitionInvalid(string propertyName)
        {
            AddError($"Invalid property definition: '{propertyName}'");
        }

        public void DuplicatedPropertyDefinition(string propertyName)
        {
            AddError($"Duplicated property definition: '{propertyName}'");
        }

        public void PropertyNotFound(string propertyName)
        {
            AddError($"Property not found: '{propertyName}'");
        }

        public void PropertyValueInvalid(string propertyName, string value)
        {
            AddError($"Invalid property value for '{propertyName}': '{value}'");
        }

        public void PropertyScopeInvalid(string scope)
        {
            AddError($"Invalid property scope: '{scope}'");
        }

        // Comment errors
        public void CommentTypeInvalid(string type)
        {
            AddError($"Invalid comment type: '{type}'");
        }

        public void CommentScopeInvalid(string scope)
        {
            AddError($"Invalid comment scope: '{scope}'");
        }

        // Extra transmitter errors
        public void ExtraTransmitterMessageNotFound(string messageId)
        {
            AddError($"Message '{messageId}' not found for extra transmitters");
        }

        public void ExtraTransmitterInvalid(string transmitterName)
        {
            AddError($"Invalid extra transmitter name: '{transmitterName}'");
        }

        // Reference errors
        public void NodeReferenceNotFound(string nodeName, string context)
        {
            AddError($"Node reference '{nodeName}' not found in {context}");
        }

        public void MessageReferenceNotFound(string messageId, string context)
        {
            AddError($"Message reference '{messageId}' not found in {context}");
        }

        public void SignalReferenceNotFound(string messageId, string signalName, string context)
        {
            AddError($"Signal reference '{signalName}' in message '{messageId}' not found in {context}");
        }

        // General errors
        public void UnexpectedError(string message)
        {
            AddError($"Unexpected error: {message}");
        }

        public void Warning(string message)
        {
            AddWarning(message);
        }

        public void Clear()
        {
            CurrentSheet = null;
            CurrentRow = 0;
            m_errors.Clear();
            m_warnings.Clear();
        }

        /// <summary>
        /// Gets the list of all errors collected during parsing
        /// </summary>
        public IList<string> GetErrorList()
        {
            return m_errors;
        }

        /// <summary>
        /// Gets the list of all warnings collected during parsing
        /// </summary>
        public IList<string> GetWarningList()
        {
            return m_warnings;
        }

        /// <summary>
        /// Returns true if any errors were collected
        /// </summary>
        public bool HasErrors()
        {
            return m_errors.Count > 0;
        }

        /// <summary>
        /// Returns true if any warnings were collected
        /// </summary>
        public bool HasWarnings()
        {
            return m_warnings.Count > 0;
        }
    }
}
