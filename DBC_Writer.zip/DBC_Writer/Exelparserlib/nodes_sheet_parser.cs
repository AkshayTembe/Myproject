// NodesSheetParser.cs
using System.Linq;
using DbcParserLib.Excel.Helpers;
using DbcParserLib.Excel.Models;
using DbcParserLib.Excel.Observers;
using DbcParserLib.Model;
using OfficeOpenXml;

namespace DbcParserLib.Excel.SheetParsers
{
    /// <summary>
    /// Parses the Nodes sheet
    /// Format: NodeName
    /// </summary>
    internal class NodesSheetParser : SheetParserBase
    {
        public override string SheetName => "Nodes";
        public override bool IsRequired => true;

        protected override string[] GetRequiredColumns()
        {
            return new[] { "NodeName" };
        }

        protected override bool ParseSheet(ExcelWorksheet worksheet, ExcelDbcData data, IExcelParseFailureObserver observer)
        {
            var maxRow = worksheet.Dimension.End.Row;
            var nodeNameCol = ExcelHelpers.GetColumnIndex(worksheet, "NodeName");

            if (nodeNameCol == -1)
            {
                observer.SheetHeaderMissing(SheetName, "NodeName");
                return false;
            }

            var parsedSuccessfully = true;
            var nodeNames = new System.Collections.Generic.HashSet<string>();

            // Start from row 2 (row 1 is header)
            for (int row = 2; row <= maxRow; row++)
            {
                observer.CurrentRow = row;

                // Skip empty rows
                if (IsRowEmpty(worksheet, row))
                    continue;

                var nodeName = ExcelHelpers.GetCellStringValue(worksheet, row, nodeNameCol);

                if (string.IsNullOrWhiteSpace(nodeName))
                {
                    observer.MissingRequiredField("NodeName");
                    parsedSuccessfully = false;
                    continue;
                }

                nodeName = nodeName.Trim();

                // Validate node name
                if (!ValidationHelpers.IsValidDbcIdentifier(nodeName))
                {
                    observer.NodeNameInvalid(nodeName);
                    parsedSuccessfully = false;
                    continue;
                }

                // Check for duplicates
                if (nodeNames.Contains(nodeName))
                {
                    observer.DuplicatedNode(nodeName);
                    parsedSuccessfully = false;
                    continue;
                }

                nodeNames.Add(nodeName);

                // Create Node object
                var node = new Node
                {
                    Name = nodeName,
                    Comment = string.Empty
                };

                data.Nodes.Add(node);
            }

            observer.CurrentRow = 0;
            return parsedSuccessfully;
        }
    }
}
