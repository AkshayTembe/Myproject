// ExcelHelpers.cs
using System;
using System.Globalization;
using System.Linq;
using OfficeOpenXml;

namespace DbcParserLib.Excel.Helpers
{
    /// <summary>
    /// Helper utilities for reading Excel cells with type safety and error handling
    /// </summary>
    public static class ExcelHelpers
    {
        /// <summary>
        /// Gets a string value from a cell, returning empty string if null or empty
        /// </summary>
        public static string GetCellStringValue(ExcelWorksheet worksheet, int row, int col)
        {
            var cellValue = worksheet.Cells[row, col].Value;
            return cellValue?.ToString()?.Trim() ?? string.Empty;
        }

        /// <summary>
        /// Gets a string value from a cell by column name
        /// </summary>
        public static string GetCellStringValue(ExcelWorksheet worksheet, int row, string columnName, int headerRow = 1)
        {
            int col = GetColumnIndex(worksheet, columnName, headerRow);
            if (col == -1) return string.Empty;
            return GetCellStringValue(worksheet, row, col);
        }

        /// <summary>
        /// Tries to parse a hex ID (0x format or decimal)
        /// </summary>
        public static bool TryParseHexId(string value, out uint id)
        {
            id = 0;
            if (string.IsNullOrWhiteSpace(value))
                return false;

            value = value.Trim();

            // Handle 0x prefix
            if (value.StartsWith("0x", StringComparison.OrdinalIgnoreCase) || 
                value.StartsWith("0X", StringComparison.OrdinalIgnoreCase))
            {
                value = value.Substring(2);
                return uint.TryParse(value, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out id);
            }

            // Try decimal parse
            return uint.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out id);
        }

        /// <summary>
        /// Tries to parse an integer value
        /// </summary>
        public static bool TryParseInt(string value, out int result)
        {
            result = 0;
            if (string.IsNullOrWhiteSpace(value))
                return false;

            return int.TryParse(value.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out result);
        }

        /// <summary>
        /// Tries to parse an unsigned integer value
        /// </summary>
        public static bool TryParseUInt(string value, out uint result)
        {
            result = 0;
            if (string.IsNullOrWhiteSpace(value))
                return false;

            return uint.TryParse(value.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out result);
        }

        /// <summary>
        /// Tries to parse a ushort value
        /// </summary>
        public static bool TryParseUShort(string value, out ushort result)
        {
            result = 0;
            if (string.IsNullOrWhiteSpace(value))
                return false;

            return ushort.TryParse(value.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out result);
        }

        /// <summary>
        /// Tries to parse a byte value
        /// </summary>
        public static bool TryParseByte(string value, out byte result)
        {
            result = 0;
            if (string.IsNullOrWhiteSpace(value))
                return false;

            return byte.TryParse(value.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out result);
        }

        /// <summary>
        /// Tries to parse a double value
        /// </summary>
        public static bool TryParseDouble(string value, out double result)
        {
            result = 0;
            if (string.IsNullOrWhiteSpace(value))
                return false;

            return double.TryParse(value.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out result);
        }

        /// <summary>
        /// Tries to parse a float value
        /// </summary>
        public static bool TryParseFloat(string value, out float result)
        {
            result = 0;
            if (string.IsNullOrWhiteSpace(value))
                return false;

            return float.TryParse(value.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out result);
        }

        /// <summary>
        /// Tries to parse a boolean value (TRUE/FALSE, 1/0, true/false)
        /// </summary>
        public static bool TryParseBoolean(string value, out bool result)
        {
            result = false;
            if (string.IsNullOrWhiteSpace(value))
                return false;

            value = value.Trim().ToUpperInvariant();

            if (value == "TRUE" || value == "1" || value == "YES")
            {
                result = true;
                return true;
            }

            if (value == "FALSE" || value == "0" || value == "NO")
            {
                result = false;
                return true;
            }

            return bool.TryParse(value, out result);
        }

        /// <summary>
        /// Gets the column index (1-based) for a column name
        /// Returns -1 if not found
        /// </summary>
        public static int GetColumnIndex(ExcelWorksheet worksheet, string columnName, int headerRow = 1)
        {
            if (worksheet == null || string.IsNullOrWhiteSpace(columnName))
                return -1;

            var maxCol = worksheet.Dimension?.End.Column ?? 0;
            for (int col = 1; col <= maxCol; col++)
            {
                var header = worksheet.Cells[headerRow, col].Value?.ToString()?.Trim();
                if (string.Equals(header, columnName, StringComparison.OrdinalIgnoreCase))
                {
                    return col;
                }
            }

            return -1;
        }

        /// <summary>
        /// Checks if a worksheet exists in the workbook
        /// </summary>
        public static bool WorksheetExists(ExcelPackage package, string sheetName)
        {
            if (package?.Workbook?.Worksheets == null)
                return false;

            return package.Workbook.Worksheets.Any(ws => 
                string.Equals(ws.Name, sheetName, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Gets a worksheet by name (case-insensitive)
        /// </summary>
        public static ExcelWorksheet GetWorksheet(ExcelPackage package, string sheetName)
        {
            if (package?.Workbook?.Worksheets == null)
                return null;

            return package.Workbook.Worksheets.FirstOrDefault(ws => 
                string.Equals(ws.Name, sheetName, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Checks if a row is empty (all cells are null or whitespace)
        /// </summary>
        public static bool IsRowEmpty(ExcelWorksheet worksheet, int row)
        {
            if (worksheet?.Dimension == null)
                return true;

            var maxCol = worksheet.Dimension.End.Column;
            for (int col = 1; col <= maxCol; col++)
            {
                var value = worksheet.Cells[row, col].Value?.ToString();
                if (!string.IsNullOrWhiteSpace(value))
                    return false;
            }

            return true;
        }

        /// <summary>
        /// Gets the number of data rows (excluding header)
        /// </summary>
        public static int GetDataRowCount(ExcelWorksheet worksheet, int headerRow = 1)
        {
            if (worksheet?.Dimension == null)
                return 0;

            var maxRow = worksheet.Dimension.End.Row;
            return Math.Max(0, maxRow - headerRow);
        }

        /// <summary>
        /// Validates that required columns exist in the worksheet
        /// </summary>
        public static bool ValidateRequiredColumns(ExcelWorksheet worksheet, string[] requiredColumns, 
            int headerRow = 1)
        {
            if (worksheet == null || requiredColumns == null)
                return false;

            foreach (var columnName in requiredColumns)
            {
                if (GetColumnIndex(worksheet, columnName, headerRow) == -1)
                    return false;
            }

            return true;
        }

        /// <summary>
        /// Parses ByteOrder@Sign format (e.g., "@0+", "@1-")
        /// </summary>
        public static bool TryParseByteOrderSign(string value, out byte byteOrder, out bool isSigned)
        {
            byteOrder = 0;
            isSigned = false;

            if (string.IsNullOrWhiteSpace(value))
                return false;

            value = value.Trim();

            // Expected format: @0+ or @1-
            if (value.Length < 3 || value[0] != '@')
                return false;

            // Parse byte order (0 or 1)
            if (value[1] == '0')
                byteOrder = 0;
            else if (value[1] == '1')
                byteOrder = 1;
            else
                return false;

            // Parse sign (+ or -)
            if (value[2] == '+')
                isSigned = false;
            else if (value[2] == '-')
                isSigned = true;
            else
                return false;

            return true;
        }

        /// <summary>
        /// Parses Factor,Offset format (e.g., "(1.0,0.0)")
        /// </summary>
        public static bool TryParseFactorOffset(string value, out double factor, out double offset)
        {
            factor = 1.0;
            offset = 0.0;

            if (string.IsNullOrWhiteSpace(value))
                return false;

            value = value.Trim();

            // Remove parentheses
            if (value.StartsWith("(") && value.EndsWith(")"))
            {
                value = value.Substring(1, value.Length - 2);
            }

            var parts = value.Split(',');
            if (parts.Length != 2)
                return false;

            if (!TryParseDouble(parts[0], out factor))
                return false;

            if (!TryParseDouble(parts[1], out offset))
                return false;

            return true;
        }

        /// <summary>
        /// Parses Min|Max format (e.g., "[0|100]")
        /// </summary>
        public static bool TryParseMinMax(string value, out double min, out double max)
        {
            min = 0.0;
            max = 0.0;

            if (string.IsNullOrWhiteSpace(value))
                return false;

            value = value.Trim();

            // Remove brackets
            if (value.StartsWith("[") && value.EndsWith("]"))
            {
                value = value.Substring(1, value.Length - 2);
            }

            var parts = value.Split('|');
            if (parts.Length != 2)
                return false;

            if (!TryParseDouble(parts[0], out min))
                return false;

            if (!TryParseDouble(parts[1], out max))
                return false;

            return true;
        }

        /// <summary>
        /// Validates identifier name (must start with letter or underscore, followed by alphanumeric or underscore)
        /// </summary>
        public static bool IsValidIdentifier(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return false;

            name = name.Trim();

            // Must start with letter or underscore
            if (!char.IsLetter(name[0]) && name[0] != '_')
                return false;

            // Rest must be alphanumeric or underscore
            for (int i = 1; i < name.Length; i++)
            {
                if (!char.IsLetterOrDigit(name[i]) && name[i] != '_')
                    return false;
            }

            return true;
        }
    }
}
