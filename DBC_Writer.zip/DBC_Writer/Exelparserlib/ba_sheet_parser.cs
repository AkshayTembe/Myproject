// BaSheetParser.cs
using System.Linq;
using DbcParserLib.Excel.Helpers;
using DbcParserLib.Excel.Models;
using DbcParserLib.Excel.Observers;
using DbcParserLib.Model;
using OfficeOpenXml;

namespace DbcParserLib.Excel.SheetParsers
{
    /// <summary>
    /// Parses the BA sheet (custom property value assignments)
    /// Format: Scope, ScopeIdentifier, AttributeName, Value
    /// Example: MESSAGE, "264", "GenMsgCycleTime", "100"
    /// Corresponds to BA_ entries in DBC files
    /// </summary>
    internal class BaSheetParser : SheetParserBase
    {
        public override string SheetName => "BA";
        public override bool IsRequired => false; // Optional sheet

        protected override string[] GetRequiredColumns()
        {
            return new[] { "Scope", "AttributeName", "Value" };
        }

        protected override bool ParseSheet(ExcelWorksheet worksheet, ExcelDbcData data, IExcelParseFailureObserver observer)
        {
            var maxRow = worksheet.Dimension.End.Row;
            
            var scopeCol = ExcelHelpers.GetColumnIndex(worksheet, "Scope");
            var scopeIdentifierCol = ExcelHelpers.GetColumnIndex(worksheet, "ScopeIdentifier");
            var attributeNameCol = ExcelHelpers.GetColumnIndex(worksheet, "AttributeName");
            var valueCol = ExcelHelpers.GetColumnIndex(worksheet, "Value");

            if (scopeCol == -1 || attributeNameCol == -1 || valueCol == -1)
            {
                if (scopeCol == -1)
                    observer.SheetHeaderMissing(SheetName, "Scope");
                if (attributeNameCol == -1)
                    observer.SheetHeaderMissing(SheetName, "AttributeName");
                if (valueCol == -1)
                    observer.SheetHeaderMissing(SheetName, "Value");
                return false;
            }

            var parsedSuccessfully = true;

            // Start from row 2 (row 1 is header)
            for (int row = 2; row <= maxRow; row++)
            {
                observer.CurrentRow = row;

                // Skip empty rows
                if (IsRowEmpty(worksheet, row))
                    continue;

                var scopeStr = ExcelHelpers.GetCellStringValue(worksheet, row, scopeCol);
                var scopeIdentifier = scopeIdentifierCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, scopeIdentifierCol) : string.Empty;
                var attributeName = ExcelHelpers.GetCellStringValue(worksheet, row, attributeNameCol);
                var value = ExcelHelpers.GetCellStringValue(worksheet, row, valueCol);

                // Parse scope
                if (!ValidationHelpers.TryParsePropertyScope(scopeStr, out CustomPropertyObjectType scope))
                {
                    observer.PropertyScopeInvalid(scopeStr);
                    parsedSuccessfully = false;
                    continue;
                }

                // Validate attribute name
                if (string.IsNullOrWhiteSpace(attributeName))
                {
                    observer.MissingRequiredField("AttributeName");
                    parsedSuccessfully = false;
                    continue;
                }

                attributeName = attributeName.Trim();

                // Check if property definition exists
                if (!data.CustomPropertyDefinitions[scope].ContainsKey(attributeName))
                {
                    observer.PropertyNotFound(attributeName);
                    parsedSuccessfully = false;
                    continue;
                }

                // Determine if value is numeric (not enclosed in quotes)
                bool isNumeric = !value.StartsWith("\"") && !value.EndsWith("\"");
                
                // Remove quotes if present
                if (value.StartsWith("\"") && value.EndsWith("\"") && value.Length >= 2)
                {
                    value = value.Substring(1, value.Length - 2);
                }

                // Create property assignment
                var assignment = new PropertyAssignment
                {
                    Scope = scope,
                    ScopeIdentifier = scopeIdentifier?.Trim() ?? string.Empty,
                    PropertyName = attributeName,
                    Value = value,
                    IsNumeric = isNumeric
                };

                // Validate scope identifier based on scope type
                if (scope != CustomPropertyObjectType.Global && string.IsNullOrWhiteSpace(scopeIdentifier))
                {
                    observer.MissingRequiredField("ScopeIdentifier");
                    parsedSuccessfully = false;
                    continue;
                }

                // Basic validation of scope identifier
                switch (scope)
                {
                    case CustomPropertyObjectType.Node:
                        if (!data.Nodes.Any(n => n.Name == scopeIdentifier))
                        {
                            observer.NodeReferenceNotFound(scopeIdentifier, $"BA assignment for '{attributeName}'");
                            parsedSuccessfully = false;
                            continue;
                        }
                        break;

                    case CustomPropertyObjectType.Message:
                        if (!ExcelHelpers.TryParseHexId(scopeIdentifier, out uint msgId) || !data.Messages.ContainsKey(msgId))
                        {
                            observer.MessageReferenceNotFound(scopeIdentifier, $"BA assignment for '{attributeName}'");
                            parsedSuccessfully = false;
                            continue;
                        }
                        break;

                    case CustomPropertyObjectType.Signal:
                        // Format: "messageId:signalName"
                        var parts = scopeIdentifier.Split(':');
                        if (parts.Length != 2)
                        {
                            observer.Warning($"Invalid signal scope identifier format: '{scopeIdentifier}'. Expected 'messageId:signalName'");
                            parsedSuccessfully = false;
                            continue;
                        }
                        
                        if (!ExcelHelpers.TryParseHexId(parts[0], out uint signalMsgId))
                        {
                            observer.MessageIdInvalid(parts[0]);
                            parsedSuccessfully = false;
                            continue;
                        }

                        if (!data.Signals.ContainsKey(signalMsgId) || 
                            !data.Signals[signalMsgId].Any(s => s.Name == parts[1]))
                        {
                            observer.SignalReferenceNotFound(parts[0], parts[1], $"BA assignment for '{attributeName}'");
                            parsedSuccessfully = false;
                            continue;
                        }
                        break;

                    case CustomPropertyObjectType.Environment:
                        if (!data.EnvironmentVariables.ContainsKey(scopeIdentifier))
                        {
                            observer.Warning($"Environment variable '{scopeIdentifier}' not found for BA assignment");
                            // Continue anyway - might be added later
                        }
                        break;
                }

                // Store assignment for later processing
                data.PropertyAssignments.Add(assignment);
            }

            observer.CurrentRow = 0;
            return parsedSuccessfully;
        }
    }
}
