// IExcelParseFailureObserver.cs
namespace DbcParserLib.Excel.Observers
{
    /// <summary>
    /// Observer interface for tracking parsing failures and warnings when reading Excel files
    /// </summary>
    public interface IExcelParseFailureObserver
    {
        /// <summary>
        /// Gets or sets the current sheet being parsed
        /// </summary>
        string CurrentSheet { get; set; }

        /// <summary>
        /// Gets or sets the current row number being parsed (1-based)
        /// </summary>
        int CurrentRow { get; set; }

        // Sheet structure errors
        void SheetNotFound(string sheetName);
        void SheetHeaderMissing(string sheetName, string expectedHeader);
        void SheetEmpty(string sheetName);

        // Data validation errors
        void InvalidHexId(string value);
        void InvalidInteger(string fieldName, string value);
        void InvalidFloat(string fieldName, string value);
        void InvalidBoolean(string fieldName, string value);
        void InvalidEnum(string fieldName, string value, string[] validValues);
        void MissingRequiredField(string fieldName);

        // Value table parsing errors
        void ValueTableFormatError(string valueTableString);
        void ValueTableDuplicate(string tableName);

        // Node errors
        void NodeNameInvalid(string nodeName);
        void DuplicatedNode(string nodeName);

        // Message errors
        void MessageIdInvalid(string messageId);
        void MessageNameInvalid(string messageName);
        void DuplicatedMessage(string messageId);
        void MessageNotFound(string messageId);

        // Signal errors
        void SignalNameInvalid(string signalName);
        void DuplicatedSignalInMessage(string messageId, string signalName);
        void SignalFormatError(string fieldName, string value);
        void SignalMessageNotFound(string messageId, string signalName);

        // Environment variable errors
        void EnvironmentVariableNameInvalid(string name);
        void DuplicatedEnvironmentVariable(string name);
        void EnvironmentVariableNotFound(string name);

        // Custom property errors
        void PropertyDefinitionInvalid(string propertyName);
        void DuplicatedPropertyDefinition(string propertyName);
        void PropertyNotFound(string propertyName);
        void PropertyValueInvalid(string propertyName, string value);
        void PropertyScopeInvalid(string scope);

        // Comment errors
        void CommentTypeInvalid(string type);
        void CommentScopeInvalid(string scope);

        // Extra transmitter errors
        void ExtraTransmitterMessageNotFound(string messageId);
        void ExtraTransmitterInvalid(string transmitterName);

        // Reference errors
        void NodeReferenceNotFound(string nodeName, string context);
        void MessageReferenceNotFound(string messageId, string context);
        void SignalReferenceNotFound(string messageId, string signalName, string context);

        // General errors
        void UnexpectedError(string message);
        void Warning(string message);

        /// <summary>
        /// Clears all accumulated errors and resets state
        /// </summary>
        void Clear();
    }
}
