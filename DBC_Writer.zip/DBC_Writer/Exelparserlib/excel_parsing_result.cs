// ExcelParsingResult.cs
using System.Collections.Generic;

namespace DbcParserLib.Excel.Models
{
    /// <summary>
    /// Result of Excel parsing operation, containing the Dbc object and any errors/warnings
    /// </summary>
    public class ExcelParsingResult
    {
        /// <summary>
        /// The parsed Dbc object (may be null if parsing failed critically)
        /// </summary>
        public Dbc Dbc { get; set; }

        /// <summary>
        /// Indicates whether parsing was successful
        /// </summary>
        public bool Success { get; set; }

        /// <summary>
        /// List of errors encountered during parsing
        /// </summary>
        public IList<string> Errors { get; set; } = new List<string>();

        /// <summary>
        /// List of warnings encountered during parsing
        /// </summary>
        public IList<string> Warnings { get; set; } = new List<string>();

        /// <summary>
        /// Creates a successful parsing result
        /// </summary>
        public static ExcelParsingResult CreateSuccess(Dbc dbc)
        {
            return new ExcelParsingResult
            {
                Dbc = dbc,
                Success = true
            };
        }

        /// <summary>
        /// Creates a successful parsing result with warnings
        /// </summary>
        public static ExcelParsingResult CreateSuccessWithWarnings(Dbc dbc, IList<string> warnings)
        {
            return new ExcelParsingResult
            {
                Dbc = dbc,
                Success = true,
                Warnings = warnings
            };
        }

        /// <summary>
        /// Creates a failed parsing result
        /// </summary>
        public static ExcelParsingResult CreateFailure(IList<string> errors)
        {
            return new ExcelParsingResult
            {
                Dbc = null,
                Success = false,
                Errors = errors
            };
        }

        /// <summary>
        /// Creates a failed parsing result with warnings
        /// </summary>
        public static ExcelParsingResult CreateFailure(IList<string> errors, IList<string> warnings)
        {
            return new ExcelParsingResult
            {
                Dbc = null,
                Success = false,
                Errors = errors,
                Warnings = warnings
            };
        }

        /// <summary>
        /// Returns true if there are any errors
        /// </summary>
        public bool HasErrors()
        {
            return Errors != null && Errors.Count > 0;
        }

        /// <summary>
        /// Returns true if there are any warnings
        /// </summary>
        public bool HasWarnings()
        {
            return Warnings != null && Warnings.Count > 0;
        }

        /// <summary>
        /// Gets the total count of errors
        /// </summary>
        public int ErrorCount => Errors?.Count ?? 0;

        /// <summary>
        /// Gets the total count of warnings
        /// </summary>
        public int WarningCount => Warnings?.Count ?? 0;

        /// <summary>
        /// Gets a summary string of the parsing result
        /// </summary>
        public string GetSummary()
        {
            if (Success)
            {
                if (HasWarnings())
                {
                    return $"Parsing succeeded with {WarningCount} warning(s).";
                }
                return "Parsing succeeded.";
            }
            else
            {
                if (HasWarnings())
                {
                    return $"Parsing failed with {ErrorCount} error(s) and {WarningCount} warning(s).";
                }
                return $"Parsing failed with {ErrorCount} error(s).";
            }
        }

        /// <summary>
        /// Gets a detailed report of all errors and warnings
        /// </summary>
        public string GetDetailedReport()
        {
            var report = new System.Text.StringBuilder();
            
            report.AppendLine(GetSummary());
            report.AppendLine();

            if (HasErrors())
            {
                report.AppendLine("ERRORS:");
                foreach (var error in Errors)
                {
                    report.AppendLine($"  - {error}");
                }
                report.AppendLine();
            }

            if (HasWarnings())
            {
                report.AppendLine("WARNINGS:");
                foreach (var warning in Warnings)
                {
                    report.AppendLine($"  - {warning}");
                }
            }

            return report.ToString();
        }
    }
}
