// ExcelDbcData.cs
using System.Collections.Generic;
using DbcParserLib.Model;

namespace DbcParserLib.Excel.Models
{
    /// <summary>
    /// Internal data structure to hold all parsed Excel data before building the final Dbc object
    /// This allows two-phase parsing: read all data first, then resolve references
    /// </summary>
    internal class ExcelDbcData
    {
        // Core entities
        public List<Node> Nodes { get; set; } = new List<Node>();
        public Dictionary<uint, Message> Messages { get; set; } = new Dictionary<uint, Message>();
        public Dictionary<uint, List<Signal>> Signals { get; set; } = new Dictionary<uint, List<Signal>>();
        public Dictionary<string, EnvironmentVariable> EnvironmentVariables { get; set; } = new Dictionary<string, EnvironmentVariable>();

        // Value tables
        public Dictionary<string, IReadOnlyDictionary<int, string>> NamedValueTables { get; set; } = new Dictionary<string, IReadOnlyDictionary<int, string>>();

        // Custom properties
        public Dictionary<CustomPropertyObjectType, Dictionary<string, CustomPropertyDefinition>> CustomPropertyDefinitions { get; set; } 
            = new Dictionary<CustomPropertyObjectType, Dictionary<string, CustomPropertyDefinition>>
            {
                { CustomPropertyObjectType.Global, new Dictionary<string, CustomPropertyDefinition>() },
                { CustomPropertyObjectType.Node, new Dictionary<string, CustomPropertyDefinition>() },
                { CustomPropertyObjectType.Message, new Dictionary<string, CustomPropertyDefinition>() },
                { CustomPropertyObjectType.Signal, new Dictionary<string, CustomPropertyDefinition>() },
                { CustomPropertyObjectType.Environment, new Dictionary<string, CustomPropertyDefinition>() }
            };

        // Property assignments (stored temporarily before being applied to objects)
        public List<PropertyAssignment> PropertyAssignments { get; set; } = new List<PropertyAssignment>();

        // Comments (stored temporarily before being applied to objects)
        public List<CommentEntry> Comments { get; set; } = new List<CommentEntry>();

        // Extra transmitters
        public Dictionary<uint, string[]> ExtraTransmitters { get; set; } = new Dictionary<uint, string[]>();

        // Global custom properties
        public Dictionary<string, CustomProperty> GlobalProperties { get; set; } = new Dictionary<string, CustomProperty>();
    }

    /// <summary>
    /// Represents a property assignment from the BA sheet
    /// </summary>
    internal class PropertyAssignment
    {
        public CustomPropertyObjectType Scope { get; set; }
        public string ScopeIdentifier { get; set; } // Node name, message ID, "msgId:signalName", or env var name
        public string PropertyName { get; set; }
        public string Value { get; set; }
        public bool IsNumeric { get; set; }
    }

    /// <summary>
    /// Represents a comment entry from the Comments sheet
    /// </summary>
    internal class CommentEntry
    {
        public string Type { get; set; } // BO, SG, BU, EV
        public string Scope { get; set; } // Message ID, "msgId:signalName", node name, or env var name
        public string Comment { get; set; }
    }

    /// <summary>
    /// Intermediate signal data from Excel before final Signal object is created
    /// </summary>
    internal class SignalData
    {
        public uint MessageId { get; set; }
        public string SignalName { get; set; }
        public ushort StartBit { get; set; }
        public ushort Length { get; set; }
        public byte ByteOrder { get; set; }
        public DbcValueType ValueType { get; set; }
        public double Factor { get; set; }
        public double Offset { get; set; }
        public double Minimum { get; set; }
        public double Maximum { get; set; }
        public string Unit { get; set; }
        public string[] Receivers { get; set; }
        public string Comment { get; set; }
        public string Multiplexing { get; set; }
        public string ValueTableString { get; set; } // Parsed later into ValueTableMap
        public IReadOnlyDictionary<int, string> ValueTableMap { get; set; }
    }

    /// <summary>
    /// Intermediate message data from Excel
    /// </summary>
    internal class MessageData
    {
        public uint Id { get; set; }
        public string IdHex { get; set; }
        public string Name { get; set; }
        public ushort Dlc { get; set; }
        public string Transmitter { get; set; }
        public bool IsExtended { get; set; }
        public string Comment { get; set; }
    }

    /// <summary>
    /// Intermediate environment variable data from Excel
    /// </summary>
    internal class EnvironmentVariableData
    {
        public string Name { get; set; }
        public EnvDataType Type { get; set; }
        public string MinValue { get; set; }
        public string MaxValue { get; set; }
        public string DefaultValue { get; set; }
        public string Unit { get; set; }
        public string NodesString { get; set; } // Comma-separated node names
        public string[] Nodes { get; set; }
        public uint? DataLength { get; set; }
        public string Comment { get; set; }
    }

    /// <summary>
    /// Intermediate custom property definition data from Excel
    /// </summary>
    internal class PropertyDefinitionData
    {
        public CustomPropertyObjectType Scope { get; set; }
        public string PropertyName { get; set; }
        public CustomPropertyDataType DataType { get; set; }
        public string MinValue { get; set; }
        public string MaxValue { get; set; }
        public string EnumValuesString { get; set; }
        public string[] EnumValues { get; set; }
    }

    /// <summary>
    /// Intermediate extra transmitter data from Excel
    /// </summary>
    internal class ExtraTransmitterData
    {
        public uint MessageId { get; set; }
        public string MessageIdStr { get; set; }
        public string TransmittersString { get; set; }
        public string[] Transmitters { get; set; }
    }
}
