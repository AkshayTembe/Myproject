// SignalsSheetParser.cs
using System.Collections.Generic;
using DbcParserLib.Excel.Helpers;
using DbcParserLib.Excel.Models;
using DbcParserLib.Excel.Observers;
using DbcParserLib.Model;
using OfficeOpenXml;

namespace DbcParserLib.Excel.SheetParsers
{
    /// <summary>
    /// Parses the Signals sheet
    /// Format: MessageID, SignalName, StartBit, Length, ByteOrder@Sign, Factor,Offset, 
    ///         Min|Max, Unit, Receivers, Comment, InitialValue, ValueType, SendType, 
    ///         Multiplexing, ValueTable
    /// </summary>
    internal class SignalsSheetParser : SheetParserBase
    {
        public override string SheetName => "Signals";
        public override bool IsRequired => false; // Messages without signals are valid

        protected override string[] GetRequiredColumns()
        {
            return new[] { "MessageID", "SignalName", "StartBit", "Length", "ByteOrder@Sign", 
                          "Factor,Offset", "Min|Max", "Unit" };
        }

        protected override bool ParseSheet(ExcelWorksheet worksheet, ExcelDbcData data, IExcelParseFailureObserver observer)
        {
            var maxRow = worksheet.Dimension.End.Row;
            
            var messageIdCol = ExcelHelpers.GetColumnIndex(worksheet, "MessageID");
            var signalNameCol = ExcelHelpers.GetColumnIndex(worksheet, "SignalName");
            var startBitCol = ExcelHelpers.GetColumnIndex(worksheet, "StartBit");
            var lengthCol = ExcelHelpers.GetColumnIndex(worksheet, "Length");
            var byteOrderSignCol = ExcelHelpers.GetColumnIndex(worksheet, "ByteOrder@Sign");
            var factorOffsetCol = ExcelHelpers.GetColumnIndex(worksheet, "Factor,Offset");
            var minMaxCol = ExcelHelpers.GetColumnIndex(worksheet, "Min|Max");
            var unitCol = ExcelHelpers.GetColumnIndex(worksheet, "Unit");
            var receiversCol = ExcelHelpers.GetColumnIndex(worksheet, "Receivers");
            var commentCol = ExcelHelpers.GetColumnIndex(worksheet, "Comment");
            var initialValueCol = ExcelHelpers.GetColumnIndex(worksheet, "InitialValue");
            var valueTypeCol = ExcelHelpers.GetColumnIndex(worksheet, "ValueType");
            var sendTypeCol = ExcelHelpers.GetColumnIndex(worksheet, "SendType");
            var multiplexingCol = ExcelHelpers.GetColumnIndex(worksheet, "Multiplexing");
            var valueTableCol = ExcelHelpers.GetColumnIndex(worksheet, "ValueTable");

            // Validate required columns
            if (messageIdCol == -1 || signalNameCol == -1 || startBitCol == -1 || lengthCol == -1 ||
                byteOrderSignCol == -1 || factorOffsetCol == -1 || minMaxCol == -1 || unitCol == -1)
            {
                if (messageIdCol == -1) observer.SheetHeaderMissing(SheetName, "MessageID");
                if (signalNameCol == -1) observer.SheetHeaderMissing(SheetName, "SignalName");
                if (startBitCol == -1) observer.SheetHeaderMissing(SheetName, "StartBit");
                if (lengthCol == -1) observer.SheetHeaderMissing(SheetName, "Length");
                if (byteOrderSignCol == -1) observer.SheetHeaderMissing(SheetName, "ByteOrder@Sign");
                if (factorOffsetCol == -1) observer.SheetHeaderMissing(SheetName, "Factor,Offset");
                if (minMaxCol == -1) observer.SheetHeaderMissing(SheetName, "Min|Max");
                if (unitCol == -1) observer.SheetHeaderMissing(SheetName, "Unit");
                return false;
            }

            var parsedSuccessfully = true;

            // Start from row 2 (row 1 is header)
            for (int row = 2; row <= maxRow; row++)
            {
                observer.CurrentRow = row;

                // Skip empty rows
                if (IsRowEmpty(worksheet, row))
                    continue;

                var messageIdStr = ExcelHelpers.GetCellStringValue(worksheet, row, messageIdCol);
                var signalName = ExcelHelpers.GetCellStringValue(worksheet, row, signalNameCol);
                var startBitStr = ExcelHelpers.GetCellStringValue(worksheet, row, startBitCol);
                var lengthStr = ExcelHelpers.GetCellStringValue(worksheet, row, lengthCol);
                var byteOrderSignStr = ExcelHelpers.GetCellStringValue(worksheet, row, byteOrderSignCol);
                var factorOffsetStr = ExcelHelpers.GetCellStringValue(worksheet, row, factorOffsetCol);
                var minMaxStr = ExcelHelpers.GetCellStringValue(worksheet, row, minMaxCol);
                var unit = ExcelHelpers.GetCellStringValue(worksheet, row, unitCol);
                var receiversStr = receiversCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, receiversCol) : string.Empty;
                var comment = commentCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, commentCol) : string.Empty;
                var initialValueStr = initialValueCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, initialValueCol) : string.Empty;
                var valueTypeStr = valueTypeCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, valueTypeCol) : string.Empty;
                var sendType = sendTypeCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, sendTypeCol) : string.Empty;
                var multiplexing = multiplexingCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, multiplexingCol) : string.Empty;
                var valueTableStr = valueTableCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, valueTableCol) : string.Empty;

                // Parse Message ID
                if (!ExcelHelpers.TryParseHexId(messageIdStr, out uint messageId))
                {
                    observer.MessageIdInvalid(messageIdStr);
                    parsedSuccessfully = false;
                    continue;
                }

                // Check if message exists
                if (!data.Messages.ContainsKey(messageId))
                {
                    observer.SignalMessageNotFound(messageIdStr, signalName);
                    parsedSuccessfully = false;
                    continue;
                }

                // Validate signal name
                if (string.IsNullOrWhiteSpace(signalName))
                {
                    observer.MissingRequiredField("SignalName");
                    parsedSuccessfully = false;
                    continue;
                }

                signalName = signalName.Trim();

                if (!ValidationHelpers.IsValidDbcIdentifier(signalName))
                {
                    observer.SignalNameInvalid(signalName);
                    parsedSuccessfully = false;
                    continue;
                }

                // Check for duplicate signals in message
                if (!data.Signals.ContainsKey(messageId))
                {
                    data.Signals[messageId] = new List<Signal>();
                }

                if (data.Signals[messageId].Any(s => s.Name == signalName))
                {
                    observer.DuplicatedSignalInMessage(messageIdStr, signalName);
                    parsedSuccessfully = false;
                    continue;
                }

                // Parse StartBit
                if (!ExcelHelpers.TryParseUShort(startBitStr, out ushort startBit))
                {
                    observer.SignalFormatError("StartBit", startBitStr);
                    parsedSuccessfully = false;
                    continue;
                }

                // Parse Length
                if (!ExcelHelpers.TryParseUShort(lengthStr, out ushort length))
                {
                    observer.SignalFormatError("Length", lengthStr);
                    parsedSuccessfully = false;
                    continue;
                }

                // Parse ByteOrder@Sign
                if (!ExcelHelpers.TryParseByteOrderSign(byteOrderSignStr, out byte byteOrder, out bool isSigned))
                {
                    observer.SignalFormatError("ByteOrder@Sign", byteOrderSignStr);
                    parsedSuccessfully = false;
                    continue;
                }

                // Parse Factor,Offset
                if (!ExcelHelpers.TryParseFactorOffset(factorOffsetStr, out double factor, out double offset))
                {
                    observer.SignalFormatError("Factor,Offset", factorOffsetStr);
                    parsedSuccessfully = false;
                    continue;
                }

                // Parse Min|Max
                if (!ExcelHelpers.TryParseMinMax(minMaxStr, out double min, out double max))
                {
                    observer.SignalFormatError("Min|Max", minMaxStr);
                    parsedSuccessfully = false;
                    continue;
                }

                // Parse receivers
                string[] receivers = ValidationHelpers.ParseReceiverList(receiversStr);

                // Parse value type
                DbcValueType valueType = isSigned ? DbcValueType.Signed : DbcValueType.Unsigned;
                if (!string.IsNullOrWhiteSpace(valueTypeStr))
                {
                    if (ValidationHelpers.TryParseSignalValueType(valueTypeStr, out var parsedValueType))
                    {
                        valueType = parsedValueType;
                    }
                    else
                    {
                        observer.Warning($"Invalid ValueType '{valueTypeStr}' for signal '{signalName}', using default");
                    }
                }

                // Parse value table
                IReadOnlyDictionary<int, string> valueTable = null;
                if (!string.IsNullOrWhiteSpace(valueTableStr))
                {
                    if (!ValueTableParser.TryParse(valueTableStr, out valueTable))
                    {
                        observer.ValueTableFormatError(valueTableStr);
                        parsedSuccessfully = false;
                        continue;
                    }
                }

                // Validate signal fits in message
                var message = data.Messages[messageId];
                if (!ValidationHelpers.IsValidSignalBitPosition(startBit, length, message.DLC))
                {
                    observer.Warning($"Signal '{signalName}' may not fit in message '{message.Name}' (StartBit={startBit}, Length={length}, DLC={message.DLC})");
                }

                // Create Signal object
                var signal = new Signal
                {
                    Name = signalName,
                    StartBit = startBit,
                    Length = length,
                    ByteOrder = byteOrder,
                    ValueType = valueType,
                    Factor = factor,
                    Offset = offset,
                    Minimum = min,
                    Maximum = max,
                    Unit = unit ?? string.Empty,
                    Receiver = receivers,
                    Comment = comment ?? string.Empty,
                    Multiplexing = multiplexing ?? string.Empty,
                    ValueTableMap = valueTable ?? new Dictionary<int, string>(),
                    Parent = message
                };

                data.Signals[messageId].Add(signal);
            }

            observer.CurrentRow = 0;
            return parsedSuccessfully;
        }
    }
}
