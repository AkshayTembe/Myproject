// ValueTableParser.cs
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace DbcParserLib.Excel.Helpers
{
    /// <summary>
    /// Parser for value table strings from Excel
    /// Supports formats: 0:"Off" 1:"On" or 0 "Off" 1 "On"
    /// </summary>
    public static class ValueTableParser
    {
        // Regex pattern to match: number:"text" or number "text"
        // Handles both with and without colon separator
        private static readonly Regex ValueTablePattern = 
            new Regex(@"(-?\d+)\s*:?\s*""([^""]*)""", RegexOptions.Compiled);

        /// <summary>
        /// Parses a value table string into a dictionary
        /// Format: 0:"Off" 1:"On" 2:"Auto" or 0 "Off" 1 "On" 2 "Auto"
        /// </summary>
        /// <param name="valueTableString">The value table string to parse</param>
        /// <param name="valueTable">The resulting dictionary</param>
        /// <returns>True if parsing succeeded, false otherwise</returns>
        public static bool TryParse(string valueTableString, out IReadOnlyDictionary<int, string> valueTable)
        {
            valueTable = null;

            if (string.IsNullOrWhiteSpace(valueTableString))
            {
                // Empty string is valid - just means no value table
                valueTable = new Dictionary<int, string>();
                return true;
            }

            var dict = new Dictionary<int, string>();

            try
            {
                var matches = ValueTablePattern.Matches(valueTableString);

                if (matches.Count == 0)
                {
                    // No valid entries found
                    return false;
                }

                foreach (Match match in matches)
                {
                    if (match.Success && match.Groups.Count >= 3)
                    {
                        var keyStr = match.Groups[1].Value;
                        var value = match.Groups[2].Value;

                        if (int.TryParse(keyStr, out int key))
                        {
                            // Check for duplicate keys
                            if (dict.ContainsKey(key))
                            {
                                // Duplicate key found
                                return false;
                            }

                            dict[key] = value;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }

                valueTable = dict;
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Parses a value table string, throwing an exception on failure
        /// </summary>
        public static IReadOnlyDictionary<int, string> Parse(string valueTableString)
        {
            if (TryParse(valueTableString, out var result))
            {
                return result;
            }

            throw new FormatException($"Failed to parse value table string: '{valueTableString}'");
        }

        /// <summary>
        /// Converts a value table dictionary back to a string format
        /// Format: 0:"Off" 1:"On" 2:"Auto"
        /// </summary>
        public static string ToString(IReadOnlyDictionary<int, string> valueTable)
        {
            if (valueTable == null || valueTable.Count == 0)
                return string.Empty;

            var sb = new StringBuilder();
            bool first = true;

            // Sort by key for consistent output
            var sortedKeys = new List<int>(valueTable.Keys);
            sortedKeys.Sort();

            foreach (var key in sortedKeys)
            {
                if (!first)
                    sb.Append(" ");

                sb.Append($"{key}:\"{EscapeValue(valueTable[key])}\"");
                first = false;
            }

            return sb.ToString();
        }

        /// <summary>
        /// Escapes special characters in value strings
        /// Currently handles quotes by replacing with single quotes
        /// </summary>
        private static string EscapeValue(string value)
        {
            if (string.IsNullOrEmpty(value))
                return string.Empty;

            // Replace double quotes with single quotes to avoid breaking the format
            return value.Replace("\"", "'");
        }

        /// <summary>
        /// Validates a value table string without parsing it
        /// </summary>
        public static bool IsValid(string valueTableString)
        {
            return TryParse(valueTableString, out _);
        }

        /// <summary>
        /// Merges two value tables, with values from the second table overriding the first
        /// </summary>
        public static IReadOnlyDictionary<int, string> Merge(
            IReadOnlyDictionary<int, string> first,
            IReadOnlyDictionary<int, string> second)
        {
            if (first == null && second == null)
                return new Dictionary<int, string>();

            if (first == null)
                return second;

            if (second == null)
                return first;

            var result = new Dictionary<int, string>(first);

            foreach (var kvp in second)
            {
                result[kvp.Key] = kvp.Value;
            }

            return result;
        }

        /// <summary>
        /// Gets a value from the table by key, or returns null if not found
        /// </summary>
        public static string GetValue(IReadOnlyDictionary<int, string> valueTable, int key)
        {
            if (valueTable == null)
                return null;

            return valueTable.TryGetValue(key, out var value) ? value : null;
        }

        /// <summary>
        /// Gets the key for a value, or returns null if not found
        /// </summary>
        public static int? GetKey(IReadOnlyDictionary<int, string> valueTable, string value)
        {
            if (valueTable == null || string.IsNullOrEmpty(value))
                return null;

            foreach (var kvp in valueTable)
            {
                if (string.Equals(kvp.Value, value, StringComparison.OrdinalIgnoreCase))
                    return kvp.Key;
            }

            return null;
        }

        /// <summary>
        /// Checks if a value table contains a specific key
        /// </summary>
        public static bool ContainsKey(IReadOnlyDictionary<int, string> valueTable, int key)
        {
            return valueTable != null && valueTable.ContainsKey(key);
        }

        /// <summary>
        /// Checks if a value table contains a specific value
        /// </summary>
        public static bool ContainsValue(IReadOnlyDictionary<int, string> valueTable, string value)
        {
            if (valueTable == null || string.IsNullOrEmpty(value))
                return false;

            foreach (var kvp in valueTable)
            {
                if (string.Equals(kvp.Value, value, StringComparison.OrdinalIgnoreCase))
                    return true;
            }

            return false;
        }
    }
}
