// ExcelWriter.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using DbcParserLib.Model;
using OfficeOpenXml;
using OfficeOpenXml.Style;

namespace DbcParserLib.Excel
{
    /// <summary>
    /// Exports DBC objects to Excel format
    /// </summary>
    public static class ExcelWriter
    {
        /// <summary>
        /// Writes a Dbc object to an Excel file
        /// </summary>
        public static void WriteToPath(string excelFilePath, Dbc dbc)
        {
            if (string.IsNullOrWhiteSpace(excelFilePath))
                throw new ArgumentNullException(nameof(excelFilePath));

            if (dbc == null)
                throw new ArgumentNullException(nameof(dbc));

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (var package = new ExcelPackage())
            {
                WriteToPackage(package, dbc);
                package.SaveAs(new FileInfo(excelFilePath));
            }
        }

        /// <summary>
        /// Writes a Dbc object to a stream
        /// </summary>
        public static void WriteToStream(Stream stream, Dbc dbc)
        {
            if (stream == null)
                throw new ArgumentNullException(nameof(stream));

            if (dbc == null)
                throw new ArgumentNullException(nameof(dbc));

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (var package = new ExcelPackage())
            {
                WriteToPackage(package, dbc);
                package.SaveAs(stream);
            }
        }

        /// <summary>
        /// Writes a Dbc object to an Excel package
        /// </summary>
        public static void WriteToPackage(ExcelPackage package, Dbc dbc)
        {
            if (package == null)
                throw new ArgumentNullException(nameof(package));

            if (dbc == null)
                throw new ArgumentNullException(nameof(dbc));

            // Write sheets in order
            WriteNodesSheet(package, dbc);
            WriteValueTablesSheet(package, dbc);
            WriteMessagesSheet(package, dbc);
            WriteSignalsSheet(package, dbc);
            WriteExtraTransmittersSheet(package, dbc);
            WriteEnvironmentVariablesSheet(package, dbc);
            WriteBaDefSheet(package, dbc);
            WriteBaSheet(package, dbc);
            WriteCommentsSheet(package, dbc);
        }

        private static void WriteNodesSheet(ExcelPackage package, Dbc dbc)
        {
            var ws = package.Workbook.Worksheets.Add("Nodes");
            
            // Header
            ws.Cells[1, 1].Value = "NodeName";
            FormatHeader(ws.Cells[1, 1, 1, 1]);

            // Data
            int row = 2;
            foreach (var node in dbc.Nodes)
            {
                ws.Cells[row, 1].Value = node.Name;
                row++;
            }

            ws.Cells.AutoFitColumns();
        }

        private static void WriteValueTablesSheet(ExcelPackage package, Dbc dbc)
        {
            if (dbc.NamedValueTables == null || !dbc.NamedValueTables.Any())
                return;

            var ws = package.Workbook.Worksheets.Add("ValueTables");
            
            // Header
            ws.Cells[1, 1].Value = "TableName";
            ws.Cells[1, 2].Value = "Values (format: key:\"value\" key:\"value\")";
            FormatHeader(ws.Cells[1, 1, 1, 2]);

            // Data
            int row = 2;
            foreach (var table in dbc.NamedValueTables)
            {
                ws.Cells[row, 1].Value = table.Key;
                ws.Cells[row, 2].Value = Helpers.ValueTableParser.ToString(table.Value);
                row++;
            }

            ws.Cells.AutoFitColumns();
        }

        private static void WriteMessagesSheet(ExcelPackage package, Dbc dbc)
        {
            var ws = package.Workbook.Worksheets.Add("Messages");
            
            // Header
            ws.Cells[1, 1].Value = "MessageID";
            ws.Cells[1, 2].Value = "MessageName";
            ws.Cells[1, 3].Value = "DLC";
            ws.Cells[1, 4].Value = "Transmitter";
            ws.Cells[1, 5].Value = "IsExtended";
            ws.Cells[1, 6].Value = "Comment";
            FormatHeader(ws.Cells[1, 1, 1, 6]);

            // Data
            int row = 2;
            foreach (var message in dbc.Messages.OrderBy(m => m.ID))
            {
                ws.Cells[row, 1].Value = $"0x{message.ID:X}";
                ws.Cells[row, 2].Value = message.Name;
                ws.Cells[row, 3].Value = message.DLC;
                ws.Cells[row, 4].Value = message.Transmitter ?? string.Empty;
                ws.Cells[row, 5].Value = message.IsExtID ? "TRUE" : "FALSE";
                ws.Cells[row, 6].Value = message.Comment ?? string.Empty;
                row++;
            }

            ws.Cells.AutoFitColumns();
        }

        private static void WriteSignalsSheet(ExcelPackage package, Dbc dbc)
        {
            var ws = package.Workbook.Worksheets.Add("Signals");
            
            // Header
            string[] headers = {
                "MessageID", "SignalName", "StartBit", "Length", "ByteOrder@Sign",
                "Factor,Offset", "Min|Max", "Unit", "Receivers", "Comment",
                "InitialValue", "ValueType", "SendType", "Multiplexing", "ValueTable"
            };
            
            for (int i = 0; i < headers.Length; i++)
            {
                ws.Cells[1, i + 1].Value = headers[i];
            }
            FormatHeader(ws.Cells[1, 1, 1, headers.Length]);

            // Data
            int row = 2;
            foreach (var message in dbc.Messages.OrderBy(m => m.ID))
            {
                foreach (var signal in message.Signals)
                {
                    ws.Cells[row, 1].Value = $"0x{message.ID:X}";
                    ws.Cells[row, 2].Value = signal.Name;
                    ws.Cells[row, 3].Value = signal.StartBit;
                    ws.Cells[row, 4].Value = signal.Length;
                    ws.Cells[row, 5].Value = $"@{signal.ByteOrder}{(signal.ValueType == DbcValueType.Signed ? "-" : "+")}";
                    ws.Cells[row, 6].Value = $"({signal.Factor},{signal.Offset})";
                    ws.Cells[row, 7].Value = $"[{signal.Minimum}|{signal.Maximum}]";
                    ws.Cells[row, 8].Value = signal.Unit ?? string.Empty;
                    ws.Cells[row, 9].Value = signal.Receiver != null ? string.Join(",", signal.Receiver) : string.Empty;
                    ws.Cells[row, 10].Value = signal.Comment ?? string.Empty;
                    ws.Cells[row, 11].Value = string.Empty; // InitialValue
                    ws.Cells[row, 12].Value = signal.ValueType.ToString();
                    ws.Cells[row, 13].Value = string.Empty; // SendType
                    ws.Cells[row, 14].Value = signal.Multiplexing ?? string.Empty;
                    ws.Cells[row, 15].Value = signal.ValueTableMap != null ? Helpers.ValueTableParser.ToString(signal.ValueTableMap) : string.Empty;
                    row++;
                }
            }

            ws.Cells.AutoFitColumns();
        }

        private static void WriteExtraTransmittersSheet(ExcelPackage package, Dbc dbc)
        {
            var messagesWithExtraTransmitters = dbc.Messages
                .Where(m => m.AdditionalTransmitters != null && m.AdditionalTransmitters.Length > 0)
                .ToList();

            if (!messagesWithExtraTransmitters.Any())
                return;

            var ws = package.Workbook.Worksheets.Add("ExtraTransmitters");
            
            // Header
            ws.Cells[1, 1].Value = "MessageID";
            ws.Cells[1, 2].Value = "AdditionalTransmitters";
            FormatHeader(ws.Cells[1, 1, 1, 2]);

            // Data
            int row = 2;
            foreach (var message in messagesWithExtraTransmitters.OrderBy(m => m.ID))
            {
                ws.Cells[row, 1].Value = $"0x{message.ID:X}";
                ws.Cells[row, 2].Value = string.Join(",", message.AdditionalTransmitters);
                row++;
            }

            ws.Cells.AutoFitColumns();
        }

        private static void WriteEnvironmentVariablesSheet(ExcelPackage package, Dbc dbc)
        {
            if (dbc.EnvironmentVariables == null || !dbc.EnvironmentVariables.Any())
                return;

            var ws = package.Workbook.Worksheets.Add("EnvironmentVariables");
            
            // Header
            ws.Cells[1, 1].Value = "Name";
            ws.Cells[1, 2].Value = "Type";
            ws.Cells[1, 3].Value = "Min";
            ws.Cells[1, 4].Value = "Max";
            ws.Cells[1, 5].Value = "Default";
            ws.Cells[1, 6].Value = "Unit";
            ws.Cells[1, 7].Value = "Nodes";
            ws.Cells[1, 8].Value = "DataLength";
            ws.Cells[1, 9].Value = "Comment";
            FormatHeader(ws.Cells[1, 1, 1, 9]);

            // Data
            int row = 2;
            foreach (var envVar in dbc.EnvironmentVariables)
            {
                ws.Cells[row, 1].Value = envVar.Name;
                ws.Cells[row, 2].Value = envVar.Type.ToString().ToUpperInvariant();
                
                if (envVar.Type == EnvDataType.Integer && envVar.IntegerEnvironmentVariable != null)
                {
                    ws.Cells[row, 3].Value = envVar.IntegerEnvironmentVariable.Minimum;
                    ws.Cells[row, 4].Value = envVar.IntegerEnvironmentVariable.Maximum;
                    ws.Cells[row, 5].Value = envVar.IntegerEnvironmentVariable.Default;
                }
                else if (envVar.Type == EnvDataType.Float && envVar.FloatEnvironmentVariable != null)
                {
                    ws.Cells[row, 3].Value = envVar.FloatEnvironmentVariable.Minimum;
                    ws.Cells[row, 4].Value = envVar.FloatEnvironmentVariable.Maximum;
                    ws.Cells[row, 5].Value = envVar.FloatEnvironmentVariable.Default;
                }

                ws.Cells[row, 6].Value = envVar.Unit ?? string.Empty;
                ws.Cells[row, 7].Value = string.Empty; // Nodes - would need to scan all nodes
                ws.Cells[row, 8].Value = envVar.DataEnvironmentVariable?.Length.ToString() ?? string.Empty;
                ws.Cells[row, 9].Value = envVar.Comment ?? string.Empty;
                row++;
            }

            ws.Cells.AutoFitColumns();
        }

        private static void WriteBaDefSheet(ExcelPackage package, Dbc dbc)
        {
            if (dbc.CustomPropertyDefinitions == null || !dbc.CustomPropertyDefinitions.Any())
                return;

            var ws = package.Workbook.Worksheets.Add("BA_DEF");
            
            // Header
            ws.Cells[1, 1].Value = "Scope";
            ws.Cells[1, 2].Value = "PropertyName";
            ws.Cells[1, 3].Value = "Type";
            ws.Cells[1, 4].Value = "Min";
            ws.Cells[1, 5].Value = "Max";
            ws.Cells[1, 6].Value = "EnumValues";
            FormatHeader(ws.Cells[1, 1, 1, 6]);

            // Data
            int row = 2;
            foreach (var scopeKvp in dbc.CustomPropertyDefinitions)
            {
                var scope = scopeKvp.Key.ToString().ToUpperInvariant();
                foreach (var propDef in scopeKvp.Value.Values)
                {
                    ws.Cells[row, 1].Value = scope;
                    ws.Cells[row, 2].Value = propDef.Name;
                    ws.Cells[row, 3].Value = propDef.DataType.ToString().ToUpperInvariant();

                    switch (propDef.DataType)
                    {
                        case CustomPropertyDataType.Integer:
                            ws.Cells[row, 4].Value = propDef.IntegerCustomProperty?.Minimum ?? 0;
                            ws.Cells[row, 5].Value = propDef.IntegerCustomProperty?.Maximum ?? 0;
                            break;
                        case CustomPropertyDataType.Hex:
                            ws.Cells[row, 4].Value = propDef.HexCustomProperty?.Minimum ?? 0;
                            ws.Cells[row, 5].Value = propDef.HexCustomProperty?.Maximum ?? 0;
                            break;
                        case CustomPropertyDataType.Float:
                            ws.Cells[row, 4].Value = propDef.FloatCustomProperty?.Minimum ?? 0.0;
                            ws.Cells[row, 5].Value = propDef.FloatCustomProperty?.Maximum ?? 0.0;
                            break;
                        case CustomPropertyDataType.Enum:
                            ws.Cells[row, 6].Value = propDef.EnumCustomProperty?.Values != null 
                                ? string.Join(",", propDef.EnumCustomProperty.Values.Select(v => $"\"{v}\""))
                                : string.Empty;
                            break;
                    }

                    row++;
                }
            }

            ws.Cells.AutoFitColumns();
        }

        private static void WriteBaSheet(ExcelPackage package, Dbc dbc)
        {
            var ws = package.Workbook.Worksheets.Add("BA");
            
            // Header
            ws.Cells[1, 1].Value = "Scope";
            ws.Cells[1, 2].Value = "ScopeIdentifier";
            ws.Cells[1, 3].Value = "AttributeName";
            ws.Cells[1, 4].Value = "Value";
            FormatHeader(ws.Cells[1, 1, 1, 4]);

            int row = 2;

            // Global properties
            if (dbc.GlobalProperties != null)
            {
                foreach (var prop in dbc.GlobalProperties)
                {
                    WritePropertyAssignment(ws, ref row, "GLOBAL", string.Empty, prop);
                }
            }

            // Node properties
            if (dbc.Nodes != null)
            {
                foreach (var node in dbc.Nodes)
                {
                    foreach (var prop in node.CustomProperties)
                    {
                        WritePropertyAssignment(ws, ref row, "NODE", node.Name, prop.Value);
                    }
                }
            }

            // Message properties
            if (dbc.Messages != null)
            {
                foreach (var message in dbc.Messages)
                {
                    foreach (var prop in message.CustomProperties)
                    {
                        WritePropertyAssignment(ws, ref row, "MESSAGE", $"0x{message.ID:X}", prop.Value);
                    }

                    // Signal properties
                    foreach (var signal in message.Signals)
                    {
                        foreach (var prop in signal.CustomProperties)
                        {
                            WritePropertyAssignment(ws, ref row, "SIGNAL", $"0x{message.ID:X}:{signal.Name}", prop.Value);
                        }
                    }
                }
            }

            // Environment variable properties
            if (dbc.EnvironmentVariables != null)
            {
                foreach (var envVar in dbc.EnvironmentVariables)
                {
                    foreach (var prop in envVar.CustomProperties)
                    {
                        WritePropertyAssignment(ws, ref row, "ENV", envVar.Name, prop.Value);
                    }
                }
            }

            ws.Cells.AutoFitColumns();
        }

        private static void WritePropertyAssignment(ExcelWorksheet ws, ref int row, string scope, string scopeId, CustomProperty prop)
        {
            ws.Cells[row, 1].Value = scope;
            ws.Cells[row, 2].Value = scopeId;
            ws.Cells[row, 3].Value = prop.CustomPropertyDefinition.Name;

            switch (prop.CustomPropertyDefinition.DataType)
            {
                case CustomPropertyDataType.Integer:
                    ws.Cells[row, 4].Value = prop.IntegerCustomProperty?.Value ?? 0;
                    break;
                case CustomPropertyDataType.Hex:
                    ws.Cells[row, 4].Value = prop.HexCustomProperty?.Value ?? 0;
                    break;
                case CustomPropertyDataType.Float:
                    ws.Cells[row, 4].Value = prop.FloatCustomProperty?.Value ?? 0.0;
                    break;
                case CustomPropertyDataType.String:
                    ws.Cells[row, 4].Value = $"\"{prop.StringCustomProperty?.Value ?? string.Empty}\"";
                    break;
                case CustomPropertyDataType.Enum:
                    ws.Cells[row, 4].Value = $"\"{prop.EnumCustomProperty?.Value ?? string.Empty}\"";
                    break;
            }

            row++;
        }

        private static void WriteCommentsSheet(ExcelPackage package, Dbc dbc)
        {
            var ws = package.Workbook.Worksheets.Add("Comments");
            
            // Header
            ws.Cells[1, 1].Value = "Type";
            ws.Cells[1, 2].Value = "Scope";
            ws.Cells[1, 3].Value = "Comment";
            FormatHeader(ws.Cells[1, 1, 1, 3]);

            int row = 2;

            // Node comments
            if (dbc.Nodes != null)
            {
                foreach (var node in dbc.Nodes.Where(n => !string.IsNullOrEmpty(n.Comment)))
                {
                    ws.Cells[row, 1].Value = "BU";
                    ws.Cells[row, 2].Value = node.Name;
                    ws.Cells[row, 3].Value = node.Comment;
                    row++;
                }
            }

            // Message and signal comments
            if (dbc.Messages != null)
            {
                foreach (var message in dbc.Messages.OrderBy(m => m.ID))
                {
                    if (!string.IsNullOrEmpty(message.Comment))
                    {
                        ws.Cells[row, 1].Value = "BO";
                        ws.Cells[row, 2].Value = message.ID.ToString();
                        ws.Cells[row, 3].Value = message.Comment;
                        row++;
                    }

                    foreach (var signal in message.Signals.Where(s => !string.IsNullOrEmpty(s.Comment)))
                    {
                        ws.Cells[row, 1].Value = "SG";
                        ws.Cells[row, 2].Value = $"{message.ID}:{signal.Name}";
                        ws.Cells[row, 3].Value = signal.Comment;
                        row++;
                    }
                }
            }

            // Environment variable comments
            if (dbc.EnvironmentVariables != null)
            {
                foreach (var envVar in dbc.EnvironmentVariables.Where(e => !string.IsNullOrEmpty(e.Comment)))
                {
                    ws.Cells[row, 1].Value = "EV";
                    ws.Cells[row, 2].Value = envVar.Name;
                    ws.Cells[row, 3].Value = envVar.Comment;
                    row++;
                }
            }

            ws.Cells.AutoFitColumns();
        }

        private static void FormatHeader(ExcelRange range)
        {
            range.Style.Font.Bold = true;
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.LightGray);
            range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
        }
    }
}
