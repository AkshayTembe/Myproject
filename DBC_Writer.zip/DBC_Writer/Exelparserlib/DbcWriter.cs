﻿// DbcWriter.cs (updated Step 4)
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using DbcParserLib.Model;

namespace DbcParserLib
{
    public static class DbcWriter
    {
        private const uint EXT_ID_FLAG = 0x80000000U;
        private const string NewLine = "\r\n";

        public static void WriteToPath(string path, Dbc dbc)
        {
            using (var fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.None))
            using (var sw = new StreamWriter(fs, Encoding.UTF8))
            {
                Write(sw, dbc);
            }
        }

        public static void WriteToStream(Stream stream, Dbc dbc)
        {
            using (var sw = new StreamWriter(stream, Encoding.UTF8, 1024, leaveOpen: true))
            {
                Write(sw, dbc);
                sw.Flush();
            }
        }

        public static void Write(TextWriter w, Dbc dbc)
        {
            if (w == null) throw new ArgumentNullException(nameof(w));
            if (dbc == null) throw new ArgumentNullException(nameof(dbc));

            // 1. Header
            WriteHeader(w);
            // 2. Nodes (BU_:)
            WriteNodes(w, dbc.Nodes);
            w.WriteLine();

            // 3. BA_DEF_ definitions (custom property definitions)
            WriteBaDefDefinitions(w, dbc.CustomPropertyDefinitions);
            w.WriteLine();

            // 4. BA_DEF_DEF_ default values for properties
            WriteBaDefDefaults(w, dbc.CustomPropertyDefinitions);
            w.WriteLine();

            // 5. Named value table definitions (VAL_TABLE_)
            WriteNamedValueTables(w, dbc.NamedValueTables);
            w.WriteLine();

            // 6. Messages and signals (BO_ and SG_)
            WriteMessagesAndSignals(w, dbc.Messages);
            w.WriteLine();

            // 7. VAL_ entries linking signals/env vars to value text maps
            WriteValueTablesFromSignals(w, dbc.Messages);
            WriteValueTablesFromEnvVars(w, dbc.EnvironmentVariables);
            w.WriteLine();

            // 8. Comments (CM_) for BO/SG/BU/EV
            WriteComments(w, dbc.Messages, dbc.Nodes, dbc.EnvironmentVariables);
            w.WriteLine();

            // 9. SIG_VALTYPE_ lines (IEEE float/double)
            WriteSignalValueTypes(w, dbc.Messages);
            w.WriteLine();

            // 10. BA_ assignments for object-specific and global custom property *values*
            WriteAllAttributeAssignments(w, dbc);
            w.WriteLine();

            // 11. EV_ and ENVVAR_DATA_ declarations (we put them last — some files differ; this keeps them grouped)
            WriteEnvVarDeclarations(w, dbc.EnvironmentVariables, dbc.Nodes);
            w.WriteLine();

            w.Flush();
        }
        private static void WriteHeader(TextWriter w)
        {
            w.Write("VERSION \"\"" + NewLine);
            w.Write(NewLine);
            w.Write(NewLine);
            w.Write("NS_ :" + NewLine);
            w.Write("\tNS_DESC_" + NewLine);
            w.Write("\tCM_" + NewLine);
            w.Write("\tBA_DEF_" + NewLine);
            w.Write("\tBA_" + NewLine);
            w.Write("\tVAL_" + NewLine);
            w.Write("\tCAT_DEF_" + NewLine);
            w.Write("\tCAT_" + NewLine);
            w.Write("\tFILTER" + NewLine);
            w.Write("\tBA_DEF_DEF_" + NewLine);
            w.Write("\tEV_DATA_" + NewLine);
            w.Write("\tENVVAR_DATA_" + NewLine);
            w.Write("\tSGTYPE_" + NewLine);
            w.Write("\tSGTYPE_VAL_" + NewLine);
            w.Write("\tBA_DEF_SGTYPE_" + NewLine);
            w.Write("\tBA_SGTYPE_" + NewLine);
            w.Write("\tSIG_TYPE_REF_" + NewLine);
            w.Write("\tVAL_TABLE_" + NewLine);
            w.Write("\tSIG_GROUP_" + NewLine);
            w.Write("\tSIG_VALTYPE_" + NewLine);
            w.Write("\tSIGTYPE_VALTYPE_" + NewLine);
            w.Write("\tBO_TX_BU_" + NewLine);
            w.Write("\tBA_DEF_REL_" + NewLine);
            w.Write("\tBA_REL_" + NewLine);
            w.Write("\tBA_DEF_DEF_REL_" + NewLine);
            w.Write("\tBU_SG_REL_" + NewLine);
            w.Write("\tBU_EV_REL_" + NewLine);
            w.Write("\tBU_BO_REL_" + NewLine);
            w.Write("\tSG_MUL_VAL_" + NewLine);
            w.Write(NewLine);
            w.Write("BS_:" + NewLine);
            w.Write(NewLine);
        }

        private static void WriteNodes(TextWriter w, IEnumerable<Node> nodes)
        {
            if (nodes == null)
            {
                w.WriteLine("BU_:");
                return;
            }

            var nodeNames = nodes.Select(n => n.Name).Where(n => !string.IsNullOrWhiteSpace(n)).ToArray();
            if (nodeNames.Length == 0)
            {
                w.WriteLine("BU_:");
                return;
            }

            w.Write("BU_:");
            foreach (var n in nodeNames)
                w.Write(" " + n);
            w.WriteLine();
        }

        private static void WriteBaDefDefinitions(TextWriter w, IReadOnlyDictionary<CustomPropertyObjectType, IReadOnlyDictionary<string, CustomPropertyDefinition>> defs)
        {
            if (defs == null) return;

            foreach (var kv in defs)
            {
                var objType = kv.Key;
                var map = kv.Value;
                if (map == null || map.Count == 0) continue;

                foreach (var def in map.Values)
                {
                    string suffix = string.Empty;
                    switch (objType)
                    {
                        case CustomPropertyObjectType.Node:
                            suffix = " BU_"; break;
                        case CustomPropertyObjectType.Message:
                            suffix = " BO_"; break;
                        case CustomPropertyObjectType.Signal:
                            suffix = " SG_"; break;
                        case CustomPropertyObjectType.Environment:
                            suffix = " EV_"; break;
                        case CustomPropertyObjectType.Global:
                        default:
                            suffix = ""; break;
                    }

                    switch (def.DataType)
                    {
                        case CustomPropertyDataType.Integer:
                            w.WriteLine($"BA_DEF_{suffix} \"{def.Name}\" INT {def.IntegerCustomProperty.Minimum} {def.IntegerCustomProperty.Maximum} ;");
                            break;
                        case CustomPropertyDataType.Hex:
                            // Print hex min/max with 0x prefix in uppercase
                            var minHex = $"0x{def.HexCustomProperty.Minimum:X}";
                            var maxHex = $"0x{def.HexCustomProperty.Maximum:X}";
                            w.WriteLine($"BA_DEF_{suffix} \"{def.Name}\" HEX {minHex} {maxHex} ;");
                            break;
                        case CustomPropertyDataType.Float:
                            w.WriteLine($"BA_DEF_{suffix} \"{def.Name}\" FLOAT {def.FloatCustomProperty.Minimum.ToString(System.Globalization.CultureInfo.InvariantCulture)} {def.FloatCustomProperty.Maximum.ToString(System.Globalization.CultureInfo.InvariantCulture)} ;");
                            break;
                        case CustomPropertyDataType.String:
                            w.WriteLine($"BA_DEF_{suffix} \"{def.Name}\" STRING ;");
                            break;
                        case CustomPropertyDataType.Enum:
                            var enumVals = string.Join(", ", def.EnumCustomProperty.Values.Select(v => $"\"{EscapeForDbc(v)}\""));
                            w.WriteLine($"BA_DEF_{suffix} \"{def.Name}\" ENUM {enumVals} ;");
                            break;
                        default:
                            break;
                    }
                }
            }
        }

        private static void WriteBaDefDefaults(TextWriter w, IReadOnlyDictionary<CustomPropertyObjectType, IReadOnlyDictionary<string, CustomPropertyDefinition>> defs)
        {
            if (defs == null) return;

            foreach (var kv in defs)
            {
                var map = kv.Value;
                if (map == null || map.Count == 0) continue;

                foreach (var def in map.Values)
                {
                    switch (def.DataType)
                    {
                        case CustomPropertyDataType.Integer:
                            if (def.IntegerCustomProperty != null)
                                w.WriteLine($"BA_DEF_DEF_ \"{def.Name}\" {def.IntegerCustomProperty.Default} ;");
                            break;
                        case CustomPropertyDataType.Hex:
                            if (def.HexCustomProperty != null)
                                w.WriteLine($"BA_DEF_DEF_ \"{def.Name}\" 0x{def.HexCustomProperty.Default:X} ;");
                            break;
                        case CustomPropertyDataType.Float:
                            if (def.FloatCustomProperty != null)
                                w.WriteLine($"BA_DEF_DEF_ \"{def.Name}\" {def.FloatCustomProperty.Default.ToString(System.Globalization.CultureInfo.InvariantCulture)} ;");
                            break;
                        case CustomPropertyDataType.String:
                            if (def.StringCustomProperty != null)
                                w.WriteLine($"BA_DEF_DEF_ \"{def.Name}\" \"{EscapeForDbc(def.StringCustomProperty.Default ?? string.Empty)}\" ;");
                            break;
                        case CustomPropertyDataType.Enum:
                            if (def.EnumCustomProperty != null)
                                w.WriteLine($"BA_DEF_DEF_ \"{def.Name}\" \"{EscapeForDbc(def.EnumCustomProperty.Default ?? string.Empty)}\" ;");
                            break;
                    }
                }
            }
        }

        private static void WriteNamedValueTables(TextWriter w, IReadOnlyDictionary<string, IReadOnlyDictionary<int, string>> namedTables)
        {
            if (namedTables == null || namedTables.Count == 0) return;

            foreach (var kv in namedTables)
            {
                var name = kv.Key;
                var map = kv.Value;
                if (map == null || map.Count == 0) continue;

                var sb = new StringBuilder();
                sb.Append($"VAL_TABLE_ {name} ");
                foreach (var pair in map)
                {
                    sb.Append($"{pair.Key} \"{EscapeForDbc(pair.Value)}\" ");
                }
                sb.Append(";");
                w.WriteLine(sb.ToString());
            }
        }

        private static void WriteMessagesAndSignals(TextWriter w, IEnumerable<Message> messages)
        {
            if (messages == null) return;

            foreach (var message in messages.OrderBy(m => m.ID))
            {
                var outId = message.IsExtID ? (message.ID + EXT_ID_FLAG) : message.ID;

                var tx = string.IsNullOrWhiteSpace(message.Transmitter) ? "" : message.Transmitter;
                w.WriteLine($"BO_ {outId} {message.Name}: {message.DLC} {tx}");

                foreach (var signal in message.Signals)
                {
                    // inside WriteMessagesAndSignals, replace the SG_ formatting line with this:

                    // prepare parts
                    var muxToken = string.IsNullOrEmpty(signal.Multiplexing) ? "" : signal.Multiplexing;
                    string muxPart = string.IsNullOrEmpty(muxToken) ? " " : $" {muxToken} ";
                    var byteOrder = signal.ByteOrder == 0 ? "0" : "1";
                    var signChar = signal.ValueType == DbcValueType.Signed ? "-" : "+";
                    var receiver = (signal.Receiver == null || signal.Receiver.Length == 0) ? "" : string.Join(",", signal.Receiver);
                    var unit = signal.Unit ?? "";

                    // Build receiver suffix: one leading space only if a receiver exists
                    var receiverSuffix = string.IsNullOrEmpty(receiver) ? "" : "  " + receiver;
                    // Now write the SG_ line with the adjusted spacing
                    w.WriteLine($" SG_ {signal.Name}{muxPart}: {signal.StartBit}|{signal.Length}@{byteOrder}{signChar} ({signal.Factor.ToString(System.Globalization.CultureInfo.InvariantCulture)},{signal.Offset.ToString(System.Globalization.CultureInfo.InvariantCulture)}) [{signal.Minimum.ToString(System.Globalization.CultureInfo.InvariantCulture)}|{signal.Maximum.ToString(System.Globalization.CultureInfo.InvariantCulture)}] \"{EscapeForDbc(unit)}\"{receiverSuffix}");
                }

                // Additional transmitters — print restored id (outId) to be consistent
                if (message.AdditionalTransmitters != null && message.AdditionalTransmitters.Length > 0)
                {
                    var txList = string.Join(", ", message.AdditionalTransmitters);
                    w.WriteLine($"BO_TX_BU_ {outId} : {txList};"); // semicolon included
                }

                w.WriteLine();
            }
        }

        private static void WriteValueTablesFromSignals(TextWriter w, IEnumerable<Message> messages)
        {
            if (messages == null) return;
            foreach (var message in messages)
            {
                foreach (var signal in message.Signals)
                {
                    if (signal.ValueTableMap != null && signal.ValueTableMap.Count > 0)
                    {
                        var sb = new StringBuilder();
                        sb.Append($"VAL_ {message.ID} {signal.Name} ");
                        foreach (var kv in signal.ValueTableMap)
                        {
                            sb.Append($"{kv.Key} \"{EscapeForDbc(kv.Value)}\" ");
                        }
                        sb.Append(";");
                        w.WriteLine(sb.ToString());
                    }
                }
            }
        }

        private static void WriteValueTablesFromEnvVars(TextWriter w, IEnumerable<EnvironmentVariable> envVars)
        {
            if (envVars == null) return;
            foreach (var env in envVars)
            {
                if (env.ValueTableMap != null && env.ValueTableMap.Count > 0)
                {
                    var sb = new StringBuilder();
                    sb.Append($"VAL_ {env.Name} ");
                    foreach (var kv in env.ValueTableMap)
                    {
                        sb.Append($"{kv.Key} \"{EscapeForDbc(kv.Value)}\" ");
                    }
                    sb.Append(";");
                    w.WriteLine(sb.ToString());
                }
            }
        }

        private static void WriteComments(TextWriter w, IEnumerable<Message> messages, IEnumerable<Node> nodes, IEnumerable<EnvironmentVariable> envVars)
        {
            if (messages != null)
            {
                foreach (var m in messages)
                {
                    if (!string.IsNullOrEmpty(m.Comment))
                        w.WriteLine($"CM_ BO_ {m.ID} \"{EscapeForDbc(m.Comment)}\";");

                    foreach (var s in m.Signals)
                    {
                        if (!string.IsNullOrEmpty(s.Comment))
                            w.WriteLine($"CM_ SG_ {m.ID} {s.Name} \"{EscapeForDbc(s.Comment)}\";");
                    }
                }
            }

            if (nodes != null)
            {
                foreach (var n in nodes)
                {
                    if (!string.IsNullOrEmpty(n.Comment))
                        w.WriteLine($"CM_ BU_ {n.Name} \"{EscapeForDbc(n.Comment)}\";");
                }
            }

            if (envVars != null)
            {
                foreach (var ev in envVars)
                {
                    if (!string.IsNullOrEmpty(ev.Comment))
                        w.WriteLine($"CM_ EV_ {ev.Name} \"{EscapeForDbc(ev.Comment)}\";");
                }
            }
        }

        private static void WriteSignalValueTypes(TextWriter w, IEnumerable<Message> messages)
        {
            if (messages == null) return;
            foreach (var m in messages)
            {
                foreach (var s in m.Signals)
                {
                    if (s.ValueType == DbcValueType.IEEEFloat)
                        w.WriteLine($"SIG_VALTYPE_ {m.ID} {s.Name} : 1;");
                    else if (s.ValueType == DbcValueType.IEEEDouble)
                        w.WriteLine($"SIG_VALTYPE_ {m.ID} {s.Name} : 2;");
                }
            }
        }

        private static void WriteAllAttributeAssignments(TextWriter w, Dbc dbc)
        {
            if (dbc.CustomPropertyDefinitions == null) return;

            // Global properties (BA_ "name" <value> ;)
            if (dbc.GlobalProperties != null)
            {
                foreach (var gp in dbc.GlobalProperties)
                {
                    var def = gp.CustomPropertyDefinition;
                    if (def == null) continue;
                    var value = CustomPropertyValueToStringForBa(gp, def);
                    if (value == null) continue;
                    w.WriteLine($"BA_ \"{def.Name}\" {value};");
                }
            }

            // Nodes
            if (dbc.Nodes != null)
            {
                foreach (var node in dbc.Nodes)
                {
                    foreach (var kv in node.CustomProperties)
                    {
                        var prop = kv.Value;
                        var def = prop.CustomPropertyDefinition;
                        if (def == null) continue;
                        var value = CustomPropertyValueToStringForBa(prop, def);
                        if (value == null) continue;
                        w.WriteLine($"BA_ \"{def.Name}\" BU_ {node.Name} {value};");
                    }
                }
            }

            // Messages
            if (dbc.Messages != null)
            {
                foreach (var m in dbc.Messages)
                {
                    foreach (var kv in m.CustomProperties)
                    {
                        var prop = kv.Value;
                        var def = prop.CustomPropertyDefinition;
                        if (def == null) continue;
                        var value = CustomPropertyValueToStringForBa(prop, def);
                        if (value == null) continue;
                        w.WriteLine($"BA_ \"{def.Name}\" BO_ {m.ID} {value};");
                    }
                }
            }

            // Signals
            if (dbc.Messages != null)
            {
                foreach (var m in dbc.Messages)
                {
                    foreach (var s in m.Signals)
                    {
                        foreach (var kv in s.CustomProperties)
                        {
                            var prop = kv.Value;
                            var def = prop.CustomPropertyDefinition;
                            if (def == null) continue;
                            var value = CustomPropertyValueToStringForBa(prop, def);
                            if (value == null) continue;
                            w.WriteLine($"BA_ \"{def.Name}\" SG_ {m.ID} {s.Name} {value};");
                        }
                    }
                }
            }

            // Environment Variables
            if (dbc.EnvironmentVariables != null)
            {
                foreach (var ev in dbc.EnvironmentVariables)
                {
                    foreach (var kv in ev.CustomProperties)
                    {
                        var prop = kv.Value;
                        var def = prop.CustomPropertyDefinition;
                        if (def == null) continue;
                        var value = CustomPropertyValueToStringForBa(prop, def);
                        if (value == null) continue;
                        w.WriteLine($"BA_ \"{def.Name}\" EV_ {ev.Name} {value};");
                    }
                }
            }
        }

        // Write EV_ declarations and ENVVAR_DATA_ lines (kept last)
        private static void WriteEnvVarDeclarations(TextWriter w, IEnumerable<EnvironmentVariable> envVars, IEnumerable<Node> nodes)
        {
            if (envVars == null) return;

            foreach (var ev in envVars)
            {
                var varType = ev.Type == EnvDataType.Integer ? 0U : (ev.Type == EnvDataType.Float ? 1U : (ev.Type == EnvDataType.String ? 2U : 0U));
                string min = "0", max = "0", initial = "0";
                if (ev.IntegerEnvironmentVariable != null)
                {
                    min = ev.IntegerEnvironmentVariable.Minimum.ToString(System.Globalization.CultureInfo.InvariantCulture);
                    max = ev.IntegerEnvironmentVariable.Maximum.ToString(System.Globalization.CultureInfo.InvariantCulture);
                    initial = ev.IntegerEnvironmentVariable.Default.ToString(System.Globalization.CultureInfo.InvariantCulture);
                }
                else if (ev.FloatEnvironmentVariable != null)
                {
                    min = ev.FloatEnvironmentVariable.Minimum.ToString(System.Globalization.CultureInfo.InvariantCulture);
                    max = ev.FloatEnvironmentVariable.Maximum.ToString(System.Globalization.CultureInfo.InvariantCulture);
                    initial = ev.FloatEnvironmentVariable.Default.ToString(System.Globalization.CultureInfo.InvariantCulture);
                }

                var accessNum = ev.Access == EnvAccessibility.Unrestricted ? 0 : (ev.Access == EnvAccessibility.Read ? 1 : (ev.Access == EnvAccessibility.Write ? 2 : 3));
                var useDummyLen = ev.Type == EnvDataType.String ? "800" : "";

                var nodesList = new List<string>();
                if (nodes != null)
                {
                    foreach (var node in nodes)
                    {
                        if (node.EnvironmentVariables != null && node.EnvironmentVariables.ContainsKey(ev.Name))
                            nodesList.Add(node.Name);
                    }
                }
                var nodesStr = nodesList.Count > 0 ? " " + string.Join(",", nodesList) : string.Empty;

                // EV_ <name> : <type> [<min>|<max>] "<unit>" <initial> 0 DUMMY_NODE_VECTOR800<access> <node(s)> ;
                w.WriteLine($"EV_ {ev.Name} : {varType} [{min}|{max}] \"{EscapeForDbc(ev.Unit ?? "")}\" {initial} 0 DUMMY_NODE_VECTOR{useDummyLen}{accessNum}{nodesStr} ;");

                if (ev.DataEnvironmentVariable != null)
                {
                    w.WriteLine($"ENVVAR_DATA_ {ev.Name} : {ev.DataEnvironmentVariable.Length};");
                }
            }
        }

        // Converts custom property value to BA_ representation; hex gets 0x prefix
        private static string CustomPropertyValueToStringForBa(CustomProperty prop, CustomPropertyDefinition def)
        {
            if (prop == null || def == null) return null;

            switch (def.DataType)
            {
                case CustomPropertyDataType.Integer:
                    return prop.IntegerCustomProperty?.Value.ToString(System.Globalization.CultureInfo.InvariantCulture);
                case CustomPropertyDataType.Hex:
                    if (prop.HexCustomProperty == null) return null;
                    return $"0x{prop.HexCustomProperty.Value:X}"; // uppercase hex with 0x
                case CustomPropertyDataType.Float:
                    return prop.FloatCustomProperty?.Value.ToString(System.Globalization.CultureInfo.InvariantCulture);
                case CustomPropertyDataType.String:
                    return $"\"{EscapeForDbc(prop.StringCustomProperty?.Value ?? string.Empty)}\"";
                case CustomPropertyDataType.Enum:
                    return $"\"{EscapeForDbc(prop.EnumCustomProperty?.Value ?? string.Empty)}\"";
                default:
                    return null;
            }
        }

        // Escape function: keep newlines, replace double-quotes with single quotes
        private static string EscapeForDbc(string value)
        {
            if (value == null) return string.Empty;
            var normalized = value.Replace("\r\n", "\n").Replace("\r", "\n");
            return normalized.Replace("\"", "'").TrimEnd('\n'); // trim final newline to avoid adding extra blank lines inside quotes
        }
    }
}
