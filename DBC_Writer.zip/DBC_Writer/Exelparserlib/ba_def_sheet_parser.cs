// BaDefSheetParser.cs
using DbcParserLib.Excel.Helpers;
using DbcParserLib.Excel.Models;
using DbcParserLib.Excel.Observers;
using DbcParserLib.Model;
using OfficeOpenXml;

namespace DbcParserLib.Excel.SheetParsers
{
    /// <summary>
    /// Parses the BA_DEF sheet (custom property definitions)
    /// Format: Scope, PropertyName, Type, Min, Max, EnumValues
    /// Example: MESSAGE, "GenMsgCycleTime", INT, 0, 10000, ""
    /// Corresponds to BA_DEF_ entries in DBC files
    /// </summary>
    internal class BaDefSheetParser : SheetParserBase
    {
        public override string SheetName => "BA_DEF";
        public override bool IsRequired => false; // Optional sheet

        protected override string[] GetRequiredColumns()
        {
            return new[] { "Scope", "PropertyName", "Type" };
        }

        protected override bool ParseSheet(ExcelWorksheet worksheet, ExcelDbcData data, IExcelParseFailureObserver observer)
        {
            var maxRow = worksheet.Dimension.End.Row;
            
            var scopeCol = ExcelHelpers.GetColumnIndex(worksheet, "Scope");
            var propertyNameCol = ExcelHelpers.GetColumnIndex(worksheet, "PropertyName");
            var typeCol = ExcelHelpers.GetColumnIndex(worksheet, "Type");
            var minCol = ExcelHelpers.GetColumnIndex(worksheet, "Min");
            var maxCol = ExcelHelpers.GetColumnIndex(worksheet, "Max");
            var enumValuesCol = ExcelHelpers.GetColumnIndex(worksheet, "EnumValues");

            if (scopeCol == -1 || propertyNameCol == -1 || typeCol == -1)
            {
                if (scopeCol == -1)
                    observer.SheetHeaderMissing(SheetName, "Scope");
                if (propertyNameCol == -1)
                    observer.SheetHeaderMissing(SheetName, "PropertyName");
                if (typeCol == -1)
                    observer.SheetHeaderMissing(SheetName, "Type");
                return false;
            }

            var parsedSuccessfully = true;

            // Create a temporary observer for property definition parsing
            var tempObserver = new Observers.SilentExcelObserver();

            // Start from row 2 (row 1 is header)
            for (int row = 2; row <= maxRow; row++)
            {
                observer.CurrentRow = row;

                // Skip empty rows
                if (IsRowEmpty(worksheet, row))
                    continue;

                var scopeStr = ExcelHelpers.GetCellStringValue(worksheet, row, scopeCol);
                var propertyName = ExcelHelpers.GetCellStringValue(worksheet, row, propertyNameCol);
                var typeStr = ExcelHelpers.GetCellStringValue(worksheet, row, typeCol);
                var minStr = minCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, minCol) : string.Empty;
                var maxStr = maxCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, maxCol) : string.Empty;
                var enumValuesStr = enumValuesCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, enumValuesCol) : string.Empty;

                // Parse scope
                if (!ValidationHelpers.TryParsePropertyScope(scopeStr, out CustomPropertyObjectType scope))
                {
                    observer.PropertyScopeInvalid(scopeStr);
                    parsedSuccessfully = false;
                    continue;
                }

                // Validate property name
                if (string.IsNullOrWhiteSpace(propertyName))
                {
                    observer.MissingRequiredField("PropertyName");
                    parsedSuccessfully = false;
                    continue;
                }

                propertyName = propertyName.Trim();

                // Check for duplicate property definitions in this scope
                if (data.CustomPropertyDefinitions[scope].ContainsKey(propertyName))
                {
                    observer.DuplicatedPropertyDefinition(propertyName);
                    parsedSuccessfully = false;
                    continue;
                }

                // Parse data type
                if (!ValidationHelpers.TryParsePropertyDataType(typeStr, out CustomPropertyDataType dataType))
                {
                    observer.InvalidEnum("Type", typeStr, new[] { "INT", "HEX", "FLOAT", "STRING", "ENUM" });
                    parsedSuccessfully = false;
                    continue;
                }

                // Create property definition
                var propDef = new CustomPropertyDefinition((DbcParserLib.Observers.IParseFailureObserver)tempObserver)
                {
                    Name = propertyName,
                    DataType = dataType
                };

                // Parse type-specific data
                switch (dataType)
                {
                    case CustomPropertyDataType.Integer:
                        int minInt = 0, maxInt = 0;
                        
                        if (!string.IsNullOrWhiteSpace(minStr) && !ExcelHelpers.TryParseInt(minStr, out minInt))
                        {
                            observer.InvalidInteger("Min", minStr);
                            parsedSuccessfully = false;
                            continue;
                        }

                        if (!string.IsNullOrWhiteSpace(maxStr) && !ExcelHelpers.TryParseInt(maxStr, out maxInt))
                        {
                            observer.InvalidInteger("Max", maxStr);
                            parsedSuccessfully = false;
                            continue;
                        }

                        propDef.IntegerCustomProperty = new NumericCustomPropertyDefinition<int>
                        {
                            Minimum = minInt,
                            Maximum = maxInt,
                            Default = minInt // Default to minimum
                        };
                        break;

                    case CustomPropertyDataType.Hex:
                        int minHex = 0, maxHex = 0;
                        
                        if (!string.IsNullOrWhiteSpace(minStr) && !ExcelHelpers.TryParseInt(minStr, out minHex))
                        {
                            observer.InvalidInteger("Min", minStr);
                            parsedSuccessfully = false;
                            continue;
                        }

                        if (!string.IsNullOrWhiteSpace(maxStr) && !ExcelHelpers.TryParseInt(maxStr, out maxHex))
                        {
                            observer.InvalidInteger("Max", maxStr);
                            parsedSuccessfully = false;
                            continue;
                        }

                        propDef.HexCustomProperty = new NumericCustomPropertyDefinition<int>
                        {
                            Minimum = minHex,
                            Maximum = maxHex,
                            Default = minHex // Default to minimum
                        };
                        break;

                    case CustomPropertyDataType.Float:
                        double minFloat = 0.0, maxFloat = 0.0;
                        
                        if (!string.IsNullOrWhiteSpace(minStr) && !ExcelHelpers.TryParseDouble(minStr, out minFloat))
                        {
                            observer.InvalidFloat("Min", minStr);
                            parsedSuccessfully = false;
                            continue;
                        }

                        if (!string.IsNullOrWhiteSpace(maxStr) && !ExcelHelpers.TryParseDouble(maxStr, out maxFloat))
                        {
                            observer.InvalidFloat("Max", maxStr);
                            parsedSuccessfully = false;
                            continue;
                        }

                        propDef.FloatCustomProperty = new NumericCustomPropertyDefinition<double>
                        {
                            Minimum = minFloat,
                            Maximum = maxFloat,
                            Default = minFloat // Default to minimum
                        };
                        break;

                    case CustomPropertyDataType.String:
                        propDef.StringCustomProperty = new StringCustomPropertyDefinition
                        {
                            Default = string.Empty
                        };
                        break;

                    case CustomPropertyDataType.Enum:
                        if (string.IsNullOrWhiteSpace(enumValuesStr))
                        {
                            observer.MissingRequiredField("EnumValues");
                            parsedSuccessfully = false;
                            continue;
                        }

                        if (!ValidationHelpers.TryParseEnumValues(enumValuesStr, out string[] enumValues))
                        {
                            observer.PropertyDefinitionInvalid(propertyName);
                            parsedSuccessfully = false;
                            continue;
                        }

                        propDef.EnumCustomProperty = new EnumCustomPropertyDefinition
                        {
                            Values = enumValues,
                            Default = enumValues.Length > 0 ? enumValues[0] : string.Empty
                        };
                        break;
                }

                // Store property definition
                data.CustomPropertyDefinitions[scope][propertyName] = propDef;
            }

            observer.CurrentRow = 0;
            return parsedSuccessfully;
        }
    }
}
