// ExtraTransmittersSheetParser.cs
using System.Linq;
using DbcParserLib.Excel.Helpers;
using DbcParserLib.Excel.Models;
using DbcParserLib.Excel.Observers;
using OfficeOpenXml;

namespace DbcParserLib.Excel.SheetParsers
{
    /// <summary>
    /// Parses the ExtraTransmitters sheet
    /// Format: MessageID, AdditionalTransmitters (comma-separated)
    /// Example: 0x108, "GTW,MCU"
    /// Corresponds to BO_TX_BU_ entries in DBC files
    /// </summary>
    internal class ExtraTransmittersSheetParser : SheetParserBase
    {
        public override string SheetName => "ExtraTransmitters";
        public override bool IsRequired => false; // Optional sheet

        protected override string[] GetRequiredColumns()
        {
            return new[] { "MessageID", "AdditionalTransmitters" };
        }

        protected override bool ParseSheet(ExcelWorksheet worksheet, ExcelDbcData data, IExcelParseFailureObserver observer)
        {
            var maxRow = worksheet.Dimension.End.Row;
            
            var messageIdCol = ExcelHelpers.GetColumnIndex(worksheet, "MessageID");
            var transmittersCol = ExcelHelpers.GetColumnIndex(worksheet, "AdditionalTransmitters");

            if (messageIdCol == -1 || transmittersCol == -1)
            {
                if (messageIdCol == -1)
                    observer.SheetHeaderMissing(SheetName, "MessageID");
                if (transmittersCol == -1)
                    observer.SheetHeaderMissing(SheetName, "AdditionalTransmitters");
                return false;
            }

            var parsedSuccessfully = true;

            // Start from row 2 (row 1 is header)
            for (int row = 2; row <= maxRow; row++)
            {
                observer.CurrentRow = row;

                // Skip empty rows
                if (IsRowEmpty(worksheet, row))
                    continue;

                var messageIdStr = ExcelHelpers.GetCellStringValue(worksheet, row, messageIdCol);
                var transmittersStr = ExcelHelpers.GetCellStringValue(worksheet, row, transmittersCol);

                // Parse Message ID
                if (!ExcelHelpers.TryParseHexId(messageIdStr, out uint messageId))
                {
                    observer.MessageIdInvalid(messageIdStr);
                    parsedSuccessfully = false;
                    continue;
                }

                // Check if message exists
                if (!data.Messages.ContainsKey(messageId))
                {
                    observer.ExtraTransmitterMessageNotFound(messageIdStr);
                    parsedSuccessfully = false;
                    continue;
                }

                // Parse transmitters list
                if (string.IsNullOrWhiteSpace(transmittersStr))
                {
                    observer.Warning($"Empty transmitters list for message 0x{messageId:X}");
                    continue;
                }

                var transmitters = transmittersStr.Split(new[] { ',', ' ' }, System.StringSplitOptions.RemoveEmptyEntries)
                                                  .Select(t => t.Trim())
                                                  .Where(t => !string.IsNullOrEmpty(t))
                                                  .ToArray();

                if (transmitters.Length == 0)
                {
                    observer.Warning($"Empty transmitters list for message 0x{messageId:X}");
                    continue;
                }

                // Validate each transmitter name
                foreach (var transmitter in transmitters)
                {
                    if (!ValidationHelpers.IsValidDbcIdentifier(transmitter))
                    {
                        observer.ExtraTransmitterInvalid(transmitter);
                        parsedSuccessfully = false;
                        break;
                    }

                    // Check if transmitter node exists (warning only)
                    if (!data.Nodes.Any(n => n.Name == transmitter))
                    {
                        observer.NodeReferenceNotFound(transmitter, $"extra transmitters for message 0x{messageId:X}");
                        // Continue anyway - node might be added later or it's a special value
                    }
                }

                // Check for duplicate entry
                if (data.ExtraTransmitters.ContainsKey(messageId))
                {
                    observer.Warning($"Duplicate extra transmitters entry for message 0x{messageId:X}");
                    // Overwrite with new value
                }

                // Store extra transmitters
                data.ExtraTransmitters[messageId] = transmitters;
            }

            observer.CurrentRow = 0;
            return parsedSuccessfully;
        }
    }
}
