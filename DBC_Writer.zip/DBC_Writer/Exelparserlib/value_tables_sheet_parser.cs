// ValueTablesSheetParser.cs
using System.Collections.Generic;
using DbcParserLib.Excel.Helpers;
using DbcParserLib.Excel.Models;
using DbcParserLib.Excel.Observers;
using OfficeOpenXml;

namespace DbcParserLib.Excel.SheetParsers
{
    /// <summary>
    /// Parses the ValueTables sheet
    /// Format: TableName, Values (format: key:"value" key:"value")
    /// Example: TableName = "DI_gear", Values = 0:"Invalid" 1:"P" 2:"R" 3:"N" 4:"D"
    /// </summary>
    internal class ValueTablesSheetParser : SheetParserBase
    {
        public override string SheetName => "ValueTables";
        public override bool IsRequired => false; // Optional sheet

        protected override string[] GetRequiredColumns()
        {
            return new[] { "TableName", "Values" };
        }

        protected override bool ParseSheet(ExcelWorksheet worksheet, ExcelDbcData data, IExcelParseFailureObserver observer)
        {
            var maxRow = worksheet.Dimension.End.Row;
            var tableNameCol = ExcelHelpers.GetColumnIndex(worksheet, "TableName");
            var valuesCol = ExcelHelpers.GetColumnIndex(worksheet, "Values");

            if (tableNameCol == -1 || valuesCol == -1)
            {
                if (tableNameCol == -1)
                    observer.SheetHeaderMissing(SheetName, "TableName");
                if (valuesCol == -1)
                    observer.SheetHeaderMissing(SheetName, "Values");
                return false;
            }

            var parsedSuccessfully = true;

            // Start from row 2 (row 1 is header)
            for (int row = 2; row <= maxRow; row++)
            {
                observer.CurrentRow = row;

                // Skip empty rows
                if (IsRowEmpty(worksheet, row))
                    continue;

                var tableName = ExcelHelpers.GetCellStringValue(worksheet, row, tableNameCol);
                var valuesString = ExcelHelpers.GetCellStringValue(worksheet, row, valuesCol);

                // Validate table name
                if (string.IsNullOrWhiteSpace(tableName))
                {
                    observer.MissingRequiredField("TableName");
                    parsedSuccessfully = false;
                    continue;
                }

                tableName = tableName.Trim();

                // Validate table name format
                if (!ValidationHelpers.IsValidDbcIdentifier(tableName))
                {
                    observer.Warning($"Invalid value table name: '{tableName}'");
                    // Continue anyway - some DBC files have non-standard names
                }

                // Check for duplicate table names
                if (data.NamedValueTables.ContainsKey(tableName))
                {
                    observer.ValueTableDuplicate(tableName);
                    parsedSuccessfully = false;
                    continue;
                }

                // Parse the values string
                if (string.IsNullOrWhiteSpace(valuesString))
                {
                    // Empty value table is valid
                    data.NamedValueTables[tableName] = new Dictionary<int, string>();
                    continue;
                }

                if (!ValueTableParser.TryParse(valuesString, out var valueTable))
                {
                    observer.ValueTableFormatError(valuesString);
                    parsedSuccessfully = false;
                    continue;
                }

                // Store the parsed value table
                data.NamedValueTables[tableName] = valueTable;
            }

            observer.CurrentRow = 0;
            return parsedSuccessfully;
        }
    }
}
