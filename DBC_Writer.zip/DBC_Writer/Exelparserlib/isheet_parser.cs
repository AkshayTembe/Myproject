// ISheetParser.cs
using DbcParserLib.Excel.Models;
using DbcParserLib.Excel.Observers;
using OfficeOpenXml;

namespace DbcParserLib.Excel.SheetParsers
{
    /// <summary>
    /// Interface for parsing individual Excel sheets
    /// Each sheet type (Nodes, Messages, Signals, etc.) has its own parser implementation
    /// </summary>
    internal interface ISheetParser
    {
        /// <summary>
        /// Gets the name of the sheet this parser handles
        /// </summary>
        string SheetName { get; }

        /// <summary>
        /// Indicates whether this sheet is required for valid DBC parsing
        /// </summary>
        bool IsRequired { get; }

        /// <summary>
        /// Parses the sheet and populates the ExcelDbcData object
        /// </summary>
        /// <param name="package">The Excel package containing the workbook</param>
        /// <param name="data">The data object to populate</param>
        /// <param name="observer">Observer for reporting errors and warnings</param>
        /// <returns>True if parsing succeeded, false otherwise</returns>
        bool Parse(ExcelPackage package, ExcelDbcData data, IExcelParseFailureObserver observer);
    }

    /// <summary>
    /// Base class for sheet parsers providing common functionality
    /// </summary>
    internal abstract class SheetParserBase : ISheetParser
    {
        public abstract string SheetName { get; }
        public abstract bool IsRequired { get; }

        public bool Parse(ExcelPackage package, ExcelDbcData data, IExcelParseFailureObserver observer)
        {
            observer.CurrentSheet = SheetName;

            var worksheet = Helpers.ExcelHelpers.GetWorksheet(package, SheetName);

            if (worksheet == null)
            {
                if (IsRequired)
                {
                    observer.SheetNotFound(SheetName);
                    return false;
                }
                else
                {
                    // Optional sheet not found - not an error
                    return true;
                }
            }

            // Check if sheet is empty
            if (worksheet.Dimension == null || worksheet.Dimension.End.Row < 2)
            {
                if (IsRequired)
                {
                    observer.SheetEmpty(SheetName);
                    return false;
                }
                else
                {
                    observer.Warning($"Optional sheet '{SheetName}' is empty");
                    return true;
                }
            }

            // Validate required columns
            var requiredColumns = GetRequiredColumns();
            if (requiredColumns != null && requiredColumns.Length > 0)
            {
                if (!Helpers.ExcelHelpers.ValidateRequiredColumns(worksheet, requiredColumns))
                {
                    foreach (var column in requiredColumns)
                    {
                        if (Helpers.ExcelHelpers.GetColumnIndex(worksheet, column) == -1)
                        {
                            observer.SheetHeaderMissing(SheetName, column);
                        }
                    }
                    return false;
                }
            }

            // Parse the sheet data
            return ParseSheet(worksheet, data, observer);
        }

        /// <summary>
        /// Gets the list of required column names for this sheet
        /// </summary>
        protected abstract string[] GetRequiredColumns();

        /// <summary>
        /// Parses the sheet data after validation
        /// </summary>
        protected abstract bool ParseSheet(ExcelWorksheet worksheet, ExcelDbcData data, IExcelParseFailureObserver observer);

        /// <summary>
        /// Helper method to skip empty rows
        /// </summary>
        protected bool IsRowEmpty(ExcelWorksheet worksheet, int row)
        {
            return Helpers.ExcelHelpers.IsRowEmpty(worksheet, row);
        }
    }
}
