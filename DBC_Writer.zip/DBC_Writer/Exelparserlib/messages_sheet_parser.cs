// MessagesSheetParser.cs
using System.Linq;
using DbcParserLib.Excel.Helpers;
using DbcParserLib.Excel.Models;
using DbcParserLib.Excel.Observers;
using DbcParserLib.Model;
using OfficeOpenXml;

namespace DbcParserLib.Excel.SheetParsers
{
    /// <summary>
    /// Parses the Messages sheet
    /// Format: MessageID, MessageName, DLC, Transmitter, IsExtended, Comment
    /// Example: 0x108, DI_torque1, 8, DI, FALSE, ""
    /// </summary>
    internal class MessagesSheetParser : SheetParserBase
    {
        public override string SheetName => "Messages";
        public override bool IsRequired => true;

        protected override string[] GetRequiredColumns()
        {
            return new[] { "MessageID", "MessageName", "DLC" };
        }

        protected override bool ParseSheet(ExcelWorksheet worksheet, ExcelDbcData data, IExcelParseFailureObserver observer)
        {
            var maxRow = worksheet.Dimension.End.Row;
            
            var messageIdCol = ExcelHelpers.GetColumnIndex(worksheet, "MessageID");
            var messageNameCol = ExcelHelpers.GetColumnIndex(worksheet, "MessageName");
            var dlcCol = ExcelHelpers.GetColumnIndex(worksheet, "DLC");
            var transmitterCol = ExcelHelpers.GetColumnIndex(worksheet, "Transmitter");
            var isExtendedCol = ExcelHelpers.GetColumnIndex(worksheet, "IsExtended");
            var commentCol = ExcelHelpers.GetColumnIndex(worksheet, "Comment");

            if (messageIdCol == -1 || messageNameCol == -1 || dlcCol == -1)
            {
                if (messageIdCol == -1)
                    observer.SheetHeaderMissing(SheetName, "MessageID");
                if (messageNameCol == -1)
                    observer.SheetHeaderMissing(SheetName, "MessageName");
                if (dlcCol == -1)
                    observer.SheetHeaderMissing(SheetName, "DLC");
                return false;
            }

            var parsedSuccessfully = true;

            // Start from row 2 (row 1 is header)
            for (int row = 2; row <= maxRow; row++)
            {
                observer.CurrentRow = row;

                // Skip empty rows
                if (IsRowEmpty(worksheet, row))
                    continue;

                var messageIdStr = ExcelHelpers.GetCellStringValue(worksheet, row, messageIdCol);
                var messageName = ExcelHelpers.GetCellStringValue(worksheet, row, messageNameCol);
                var dlcStr = ExcelHelpers.GetCellStringValue(worksheet, row, dlcCol);
                var transmitter = transmitterCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, transmitterCol) : string.Empty;
                var isExtendedStr = isExtendedCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, isExtendedCol) : "FALSE";
                var comment = commentCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, commentCol) : string.Empty;

                // Parse Message ID
                if (!ExcelHelpers.TryParseHexId(messageIdStr, out uint messageId))
                {
                    observer.MessageIdInvalid(messageIdStr);
                    parsedSuccessfully = false;
                    continue;
                }

                // Validate message name
                if (string.IsNullOrWhiteSpace(messageName))
                {
                    observer.MissingRequiredField("MessageName");
                    parsedSuccessfully = false;
                    continue;
                }

                messageName = messageName.Trim();

                if (!ValidationHelpers.IsValidDbcIdentifier(messageName))
                {
                    observer.MessageNameInvalid(messageName);
                    parsedSuccessfully = false;
                    continue;
                }

                // Parse DLC
                if (!ExcelHelpers.TryParseUShort(dlcStr, out ushort dlc))
                {
                    observer.InvalidInteger("DLC", dlcStr);
                    parsedSuccessfully = false;
                    continue;
                }

                // Parse IsExtended
                if (!ExcelHelpers.TryParseBoolean(isExtendedStr, out bool isExtended))
                {
                    observer.InvalidBoolean("IsExtended", isExtendedStr);
                    parsedSuccessfully = false;
                    continue;
                }

                // Validate DLC
                if (!ValidationHelpers.IsValidDlc(dlc))
                {
                    observer.Warning($"Message '{messageName}' has invalid DLC: {dlc}");
                    // Continue anyway - allow invalid DLC with warning
                }

                // Validate message ID
                if (!ValidationHelpers.IsValidMessageId(messageId, isExtended))
                {
                    observer.Warning($"Message '{messageName}' has invalid ID: 0x{messageId:X} for {(isExtended ? "extended" : "standard")} CAN");
                    // Continue anyway - allow invalid ID with warning
                }

                // Check for duplicate message IDs
                if (data.Messages.ContainsKey(messageId))
                {
                    observer.DuplicatedMessage($"0x{messageId:X}");
                    parsedSuccessfully = false;
                    continue;
                }

                // Validate transmitter (if provided)
                if (!string.IsNullOrWhiteSpace(transmitter))
                {
                    transmitter = transmitter.Trim();
                    if (!ValidationHelpers.IsValidDbcIdentifier(transmitter))
                    {
                        observer.Warning($"Message '{messageName}' has invalid transmitter name: '{transmitter}'");
                        // Continue anyway
                    }

                    // Check if transmitter node exists
                    if (!data.Nodes.Any(n => n.Name == transmitter))
                    {
                        observer.NodeReferenceNotFound(transmitter, $"message '{messageName}'");
                        // Continue anyway - transmitter might be added later or it's a special value
                    }
                }

                // Create Message object
                var message = new Message
                {
                    ID = messageId,
                    IsExtID = isExtended,
                    Name = messageName,
                    DLC = dlc,
                    Transmitter = transmitter ?? string.Empty,
                    Comment = comment ?? string.Empty
                };

                data.Messages[messageId] = message;
            }

            observer.CurrentRow = 0;
            return parsedSuccessfully;
        }
    }
}
