// EnvironmentVariablesSheetParser.cs
using System.Linq;
using DbcParserLib.Excel.Helpers;
using DbcParserLib.Excel.Models;
using DbcParserLib.Excel.Observers;
using DbcParserLib.Model;
using OfficeOpenXml;

namespace DbcParserLib.Excel.SheetParsers
{
    /// <summary>
    /// Parses the EnvironmentVariables sheet
    /// Format: Name, Type, Min, Max, Default, Unit, Nodes, DataLength, Comment
    /// Example: TestEnvVar, INT, 0, 100, 50, "", "Node1,Node2", "", "Test variable"
    /// Corresponds to EV_ and ENVVAR_DATA_ entries in DBC files
    /// </summary>
    internal class EnvironmentVariablesSheetParser : SheetParserBase
    {
        public override string SheetName => "EnvironmentVariables";
        public override bool IsRequired => false; // Optional sheet

        protected override string[] GetRequiredColumns()
        {
            return new[] { "Name", "Type" };
        }

        protected override bool ParseSheet(ExcelWorksheet worksheet, ExcelDbcData data, IExcelParseFailureObserver observer)
        {
            var maxRow = worksheet.Dimension.End.Row;
            
            var nameCol = ExcelHelpers.GetColumnIndex(worksheet, "Name");
            var typeCol = ExcelHelpers.GetColumnIndex(worksheet, "Type");
            var minCol = ExcelHelpers.GetColumnIndex(worksheet, "Min");
            var maxCol = ExcelHelpers.GetColumnIndex(worksheet, "Max");
            var defaultCol = ExcelHelpers.GetColumnIndex(worksheet, "Default");
            var unitCol = ExcelHelpers.GetColumnIndex(worksheet, "Unit");
            var nodesCol = ExcelHelpers.GetColumnIndex(worksheet, "Nodes");
            var dataLengthCol = ExcelHelpers.GetColumnIndex(worksheet, "DataLength");
            var commentCol = ExcelHelpers.GetColumnIndex(worksheet, "Comment");

            if (nameCol == -1 || typeCol == -1)
            {
                if (nameCol == -1)
                    observer.SheetHeaderMissing(SheetName, "Name");
                if (typeCol == -1)
                    observer.SheetHeaderMissing(SheetName, "Type");
                return false;
            }

            var parsedSuccessfully = true;

            // Start from row 2 (row 1 is header)
            for (int row = 2; row <= maxRow; row++)
            {
                observer.CurrentRow = row;

                // Skip empty rows
                if (IsRowEmpty(worksheet, row))
                    continue;

                var name = ExcelHelpers.GetCellStringValue(worksheet, row, nameCol);
                var typeStr = ExcelHelpers.GetCellStringValue(worksheet, row, typeCol);
                var minStr = minCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, minCol) : "0";
                var maxStr = maxCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, maxCol) : "0";
                var defaultStr = defaultCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, defaultCol) : "0";
                var unit = unitCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, unitCol) : string.Empty;
                var nodesStr = nodesCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, nodesCol) : string.Empty;
                var dataLengthStr = dataLengthCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, dataLengthCol) : string.Empty;
                var comment = commentCol != -1 ? ExcelHelpers.GetCellStringValue(worksheet, row, commentCol) : string.Empty;

                // Validate name
                if (string.IsNullOrWhiteSpace(name))
                {
                    observer.MissingRequiredField("Name");
                    parsedSuccessfully = false;
                    continue;
                }

                name = name.Trim();

                if (!ValidationHelpers.IsValidDbcIdentifier(name))
                {
                    observer.EnvironmentVariableNameInvalid(name);
                    parsedSuccessfully = false;
                    continue;
                }

                // Check for duplicates
                if (data.EnvironmentVariables.ContainsKey(name))
                {
                    observer.DuplicatedEnvironmentVariable(name);
                    parsedSuccessfully = false;
                    continue;
                }

                // Parse type
                if (!ValidationHelpers.TryParseEnvVarType(typeStr, out EnvDataType envType))
                {
                    observer.InvalidEnum("Type", typeStr, new[] { "INT", "FLOAT", "STRING", "DATA" });
                    parsedSuccessfully = false;
                    continue;
                }

                // Create environment variable
                var envVar = new EnvironmentVariable
                {
                    Name = name,
                    Type = envType,
                    Unit = unit ?? string.Empty,
                    Comment = comment ?? string.Empty,
                    Access = EnvAccessibility.Unrestricted // Default, can be overridden by custom properties
                };

                // Parse type-specific data
                if (envType == EnvDataType.Integer)
                {
                    if (!ExcelHelpers.TryParseInt(minStr, out int min))
                    {
                        observer.InvalidInteger("Min", minStr);
                        parsedSuccessfully = false;
                        continue;
                    }

                    if (!ExcelHelpers.TryParseInt(maxStr, out int max))
                    {
                        observer.InvalidInteger("Max", maxStr);
                        parsedSuccessfully = false;
                        continue;
                    }

                    if (!ExcelHelpers.TryParseInt(defaultStr, out int defaultVal))
                    {
                        observer.InvalidInteger("Default", defaultStr);
                        parsedSuccessfully = false;
                        continue;
                    }

                    envVar.IntegerEnvironmentVariable = new NumericEnvironmentVariable<int>
                    {
                        Minimum = min,
                        Maximum = max,
                        Default = defaultVal
                    };
                }
                else if (envType == EnvDataType.Float)
                {
                    if (!ExcelHelpers.TryParseDouble(minStr, out double min))
                    {
                        observer.InvalidFloat("Min", minStr);
                        parsedSuccessfully = false;
                        continue;
                    }

                    if (!ExcelHelpers.TryParseDouble(maxStr, out double max))
                    {
                        observer.InvalidFloat("Max", maxStr);
                        parsedSuccessfully = false;
                        continue;
                    }

                    if (!ExcelHelpers.TryParseDouble(defaultStr, out double defaultVal))
                    {
                        observer.InvalidFloat("Default", defaultStr);
                        parsedSuccessfully = false;
                        continue;
                    }

                    envVar.FloatEnvironmentVariable = new NumericEnvironmentVariable<double>
                    {
                        Minimum = min,
                        Maximum = max,
                        Default = defaultVal
                    };
                }
                else if (envType == EnvDataType.Data)
                {
                    // Parse data length
                    if (!string.IsNullOrWhiteSpace(dataLengthStr))
                    {
                        if (!ExcelHelpers.TryParseUInt(dataLengthStr, out uint dataLength))
                        {
                            observer.InvalidInteger("DataLength", dataLengthStr);
                            parsedSuccessfully = false;
                            continue;
                        }

                        envVar.DataEnvironmentVariable = new DataEnvironmentVariable
                        {
                            Length = dataLength
                        };
                    }
                }

                // Parse nodes list (for node-specific environment variables)
                if (!string.IsNullOrWhiteSpace(nodesStr))
                {
                    var nodeNames = nodesStr.Split(new[] { ',', ' ' }, System.StringSplitOptions.RemoveEmptyEntries)
                                           .Select(n => n.Trim())
                                           .Where(n => !string.IsNullOrEmpty(n))
                                           .ToArray();

                    // Validate each node exists
                    foreach (var nodeName in nodeNames)
                    {
                        if (!ValidationHelpers.IsValidDbcIdentifier(nodeName))
                        {
                            observer.Warning($"Invalid node name '{nodeName}' in environment variable '{name}'");
                            continue;
                        }

                        var node = data.Nodes.FirstOrDefault(n => n.Name == nodeName);
                        if (node == null)
                        {
                            observer.NodeReferenceNotFound(nodeName, $"environment variable '{name}'");
                            // Continue anyway - will handle in builder
                        }
                        else
                        {
                            // Add environment variable to node
                            if (!node.EnvironmentVariables.ContainsKey(name))
                            {
                                node.EnvironmentVariables[name] = envVar;
                            }
                        }
                    }
                }

                // Store environment variable
                data.EnvironmentVariables[name] = envVar;
            }

            observer.CurrentRow = 0;
            return parsedSuccessfully;
        }
    }
}
