﻿using ClosedXML.Excel;
using DbcParserLib.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;
using System.Text.RegularExpressions;

namespace ExcelParserLib
{
    internal class SignalsSheetParser : ISheetParser
    {
        private const string SheetName = "Signals";

        // quick heuristic to detect if a cell contains a full SG_ line or other DBC tokens (misaligned)
        private static readonly Regex LikelyDbcTokenRegex = new Regex(@"\bSG_\b|@|\:|BO_|VAL_|SIG_VALTYPE_|^[A-Z]{2,}_", RegexOptions.Compiled | RegexOptions.CultureInvariant);

        public void Parse(XLWorkbook wb, ParseContext ctx, IList<string> warnings)
        {
            if (!wb.TryGetWorksheet(SheetName, out var ws)) return;

            // Expect header row in row 1; iterate used rows skipping header
            foreach (var row in ws.RowsUsed().Skip(1))
            {
                try
                {
                    var rowNum = row.RowNumber();
                    string getStr(int col) => row.Cell(col).GetString()?.Trim() ?? string.Empty;

                    var msgIdRaw = getStr(1);
                    if (string.IsNullOrWhiteSpace(msgIdRaw))
                    {
                        warnings.Add($"Signals[{rowNum}]: empty MessageID cell - skipping row.");
                        continue;
                    }

                    if (!ExcelHelpers.TryParseId(msgIdRaw, out uint msgId))
                    {
                        warnings.Add($"Signals[{rowNum}]: invalid MessageID '{msgIdRaw}' - skipping row.");
                        continue;
                    }

                    if (!ctx.MessageLookup.TryGetValue(msgId, out var parent))
                    {
                        warnings.Add($"Signals[{rowNum}]: message ID {msgId} not found in parsed messages - skipping signal.");
                        continue;
                    }

                    var sigName = getStr(2);
                    if (string.IsNullOrWhiteSpace(sigName))
                    {
                        warnings.Add($"Signals[{rowNum}]: empty signal name for message {msgId} - skipping row.");
                        continue;
                    }

                    // Parse start bit
                    ushort startBit = 0;
                    var startStr = getStr(3);
                    if (!ushort.TryParse(startStr, NumberStyles.Integer, CultureInfo.InvariantCulture, out startBit))
                    {
                        warnings.Add($"Signals[{rowNum}]: invalid StartBit '{startStr}' for signal '{sigName}' in message {msgId}; defaulting to 0.");
                        startBit = 0;
                    }

                    // Parse length
                    ushort length = 0;
                    var lenStr = getStr(4);
                    if (!ushort.TryParse(lenStr, NumberStyles.Integer, CultureInfo.InvariantCulture, out length))
                    {
                        warnings.Add($"Signals[{rowNum}]: invalid Length '{lenStr}' for signal '{sigName}' in message {msgId}; defaulting to 1.");
                        length = 1;
                    }

                    // Byte order (0 or 1) - accept numeric or textual "Intel"/"Motorola"
                    byte byteOrder = 1;
                    var boStr = getStr(5);
                    if (!string.IsNullOrWhiteSpace(boStr))
                    {
                        if (int.TryParse(boStr, NumberStyles.Integer, CultureInfo.InvariantCulture, out var boInt) && (boInt == 0 || boInt == 1))
                            byteOrder = (byte)boInt;
                        else if (boStr.Equals("Intel", StringComparison.InvariantCultureIgnoreCase) || boStr.Equals("LittleEndian", StringComparison.InvariantCultureIgnoreCase))
                            byteOrder = 1;
                        else if (boStr.Equals("Motorola", StringComparison.InvariantCultureIgnoreCase) || boStr.Equals("BigEndian", StringComparison.InvariantCultureIgnoreCase))
                            byteOrder = 0;
                        else
                        {
                            warnings.Add($"Signals[{rowNum}]: unknown ByteOrder '{boStr}' for signal '{sigName}' in message {msgId}; defaulting to 1 (Intel).");
                            byteOrder = 1;
                        }
                    }

                    // Value type (+ or -) -> Signed/Unsigned mapping
                    var vtStr = getStr(6);
                    var valueType = string.IsNullOrWhiteSpace(vtStr) || vtStr == "+" ? DbcValueType.Unsigned : DbcValueType.Signed;

                    // Factor, Offset, Min, Max - parse as doubles
                    double factor = 1.0, offset = 0.0, min = 0.0, max = 0.0;
                    var factorStr = getStr(7);
                    if (!double.TryParse(factorStr, NumberStyles.Float | NumberStyles.AllowThousands, CultureInfo.InvariantCulture, out factor))
                    {
                        factor = 1.0;
                        if (!string.IsNullOrWhiteSpace(factorStr))
                            warnings.Add($"Signals[{rowNum}]: invalid Factor '{factorStr}' for '{sigName}' in message {msgId}; default 1.0 used.");
                    }
                    var offsetStr = getStr(8);
                    if (!double.TryParse(offsetStr, NumberStyles.Float | NumberStyles.AllowThousands, CultureInfo.InvariantCulture, out offset))
                    {
                        offset = 0.0;
                        if (!string.IsNullOrWhiteSpace(offsetStr))
                            warnings.Add($"Signals[{rowNum}]: invalid Offset '{offsetStr}' for '{sigName}' in message {msgId}; default 0.0 used.");
                    }
                    var minStr = getStr(9);
                    if (!double.TryParse(minStr, NumberStyles.Float | NumberStyles.AllowThousands, CultureInfo.InvariantCulture, out min))
                    {
                        if (!string.IsNullOrWhiteSpace(minStr))
                            warnings.Add($"Signals[{rowNum}]: invalid Minimum '{minStr}' for '{sigName}' in message {msgId}; left empty.");
                    }
                    var maxStr = getStr(10);
                    if (!double.TryParse(maxStr, NumberStyles.Float | NumberStyles.AllowThousands, CultureInfo.InvariantCulture, out max))
                    {
                        if (!string.IsNullOrWhiteSpace(maxStr))
                            warnings.Add($"Signals[{rowNum}]: invalid Maximum '{maxStr}' for '{sigName}' in message {msgId}; left empty.");
                    }

                    var unit = getStr(11);
                    var receiversRaw = getStr(12);
                    var receivers = string.IsNullOrWhiteSpace(receiversRaw)
                        ? new string[] { }
                        : receiversRaw.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim()).ToArray();

                    var multiplexing = getStr(13);

                    // Value table name might be in 14th column
                    var vtName = getStr(14);

                    // Detect obvious misalignment: cell contains DBC tokens (a full SG_ line etc.)
                    if (!string.IsNullOrWhiteSpace(vtName) && LikelyDbcTokenRegex.IsMatch(vtName))
                    {
                        warnings.Add($"Signals[{rowNum}]: ValueTable cell (col 14) looks like a full SG_ line or contains DBC tokens - possible column misalignment. Cell value: '{vtName}'. Treating ValueTable as empty for this signal.");
                        vtName = null;
                    }

                    IReadOnlyDictionary<int, string> vtMap = null;
                    if (!string.IsNullOrWhiteSpace(vtName) && ctx.NamedValueTables.TryGetValue(vtName, out var foundMap))
                        vtMap = foundMap;
                    else if (!string.IsNullOrWhiteSpace(vtName) && !ctx.NamedValueTables.ContainsKey(vtName))
                    {
                        warnings.Add($"Signals[{rowNum}]: value table '{vtName}' referenced by signal '{sigName}' in message {msgId} not found (check ValueTables sheet).");
                    }

                    var comment = getStr(15);

                    // Construct signal model
                    var s = new Signal
                    {
                        Parent = parent,
                        Name = sigName,
                        StartBit = startBit,
                        Length = length,
                        ByteOrder = byteOrder,
                        ValueType = valueType,
                        Factor = factor,
                        Offset = offset,
                        Minimum = double.IsNaN(min) ? 0.0 : min,
                        Maximum = double.IsNaN(max) ? 0.0 : max,
                        Unit = string.IsNullOrWhiteSpace(unit) ? null : unit,
                        Receiver = receivers,
                        Multiplexing = string.IsNullOrWhiteSpace(multiplexing) ? null : multiplexing,
                        ValueTableMap = vtMap,
                        Comment = string.IsNullOrWhiteSpace(comment) ? null : comment
                    };

                    parent.Signals.Add(s);
                }
                catch (Exception ex)
                {
                    // Catch row-level exceptions and continue parsing; include row number for easy troubleshooting
                    warnings.Add($"SignalsSheetParser: row {row.RowNumber()} parse error: {ex.Message}");
                }
            }
        }
    }
}
