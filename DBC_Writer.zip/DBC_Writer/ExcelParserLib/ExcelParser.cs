﻿using ClosedXML.Excel;
using DbcParserLib;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ExcelParserLib
{
    public class ExcelParser : IExcelParser
    {
        private readonly IList<ISheetParser> m_sheetParsers;

        public ExcelParser()
        {
            // order matters: ValueTables before Signals, Messages before Signals, BA_DEF before BA assignments, etc.
            m_sheetParsers = new ISheetParser[]
            {
                new NodesSheetParser(),
                new ValueTablesSheetParser(),
                new MessagesSheetParser(),
                new SignalsSheetParser(),
                new ExtraTransmittersSheetParser(),
                new EnvironmentVariablesSheetParser(),
                new BA_DefinitionsSheetParser(),
                new BA_AssignmentsSheetParser(),
                new CommentsSheetParser()
            };
        }

        public ExcelParseResult Parse(string excelPath)
        {
            var warnings = new List<string>();
            var ctx = new ParseContext();

            using (var wb = new XLWorkbook(excelPath))
            {
                foreach (var parser in m_sheetParsers)
                {
                    // parser decides whether a sheet exists or not; pass the workbook
                    var sheetName = parser.GetType().Name.Replace("SheetParser", string.Empty).Replace("Sheet", string.Empty);
                    // The parser will try to find a worksheet by well-known name. Instead of forcing names here,
                    // we let each parser fetch its own sheet (implementation detail).
                    // So we iterate all worksheets and call Parse on those that match names inside parser.
                    // But simpler: each parser will try to get worksheet by its expected name.
                    try
                    {
                        // parser implementations will call wb.TryGetWorksheet and skip if not present
                        parser.ParseSheet(wb, ctx, warnings);
                    }
                    catch (Exception ex)
                    {
                        warnings.Add($"Sheet parser {parser.GetType().Name} threw: {ex.Message}");
                    }
                }
            }

            // Build final Dbc using collected data
            // Prepare custom property definitions map in the shape expected by Dbc constructor:
            var cpDefsReadonly = new Dictionary<DbcParserLib.Model.CustomPropertyObjectType, IReadOnlyDictionary<string, DbcParserLib.Model.CustomPropertyDefinition>>();
            foreach (var kv in ctx.CustomPropertyDefinitions)
            {
                cpDefsReadonly[kv.Key] = new Dictionary<string, DbcParserLib.Model.CustomPropertyDefinition>(kv.Value);
            }

            var dbc = new Dbc(
                ctx.Nodes.ToArray(),
                ctx.Messages.ToArray(),
                ctx.EnvironmentVariables.ToArray(),
                new List<DbcParserLib.Model.CustomProperty>(), // global property instances can be empty initially
                ctx.NamedValueTables.ToDictionary(k => k.Key, k => k.Value),
                cpDefsReadonly
            );

            return new ExcelParseResult(dbc, warnings);
        }
    }

    // Extension method so sheet parsers can have a simple ParseSheet API without the ISheetParser signature above
    internal static class SheetParserExtensions
    {
        public static void ParseSheet(this ISheetParser parser, XLWorkbook wb, ParseContext ctx, IList<string> warnings)
        {
            // all sheet parsers should implement Parse(IXLWorksheet, ParseContext, IList<string>)
            parser.Parse(wb, ctx, warnings);
        }
    }
}
