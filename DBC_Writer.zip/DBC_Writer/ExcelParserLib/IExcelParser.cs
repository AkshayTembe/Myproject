﻿using DbcParserLib;
using System.Collections.Generic;

namespace ExcelParserLib
{
    public interface IExcelParser
    {
        /// <summary>
        /// Parse workbook at path and return result containing the built Dbc model and non-fatal warnings.
        /// </summary>
        ExcelParseResult Parse(string excelPath);
    }
}
