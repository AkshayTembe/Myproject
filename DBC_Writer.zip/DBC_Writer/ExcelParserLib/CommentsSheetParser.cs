﻿using ClosedXML.Excel;
using System;

namespace ExcelParserLib
{
    internal class CommentsSheetParser : ISheetParser
    {
        private const string SheetName = "Comments";

        public void Parse(IXLWorksheet worksheet, ParseContext ctx, IList<string> warnings) { /* unused */ }

        public void Parse(XLWorkbook wb, ParseContext ctx, IList<string> warnings)
        {
            if (!wb.TryGetWorksheet(SheetName, out var ws)) return;

            foreach (var row in ws.RowsUsed().Skip(1))
            {
                var type = row.Cell(1).GetString().Trim().ToUpperInvariant();
                var scope = row.Cell(2).GetString().Trim();
                var comment = row.Cell(3).GetString();

                if (type == "BO")
                {
                    if (ExcelHelpers.TryParseId(scope, out var mid) && ctx.MessageLookup.TryGetValue(mid, out var msg))
                        msg.Comment = comment;
                    else warnings.Add($"Comments sheet: unknown message id '{scope}'");
                }
                else if (type == "SG")
                {
                    var parts = scope.Split(':');
                    if (parts.Length == 2 && ExcelHelpers.TryParseId(parts[0], out var mid) && ctx.MessageLookup.TryGetValue(mid, out var msg))
                    {
                        var sig = msg.Signals.Find(s => s.Name == parts[1]);
                        if (sig != null) sig.Comment = comment; else warnings.Add($"Comments sheet: signal '{parts[1]}' not found in message {mid}");
                    }
                }
                else if (type == "BU")
                {
                    if (ctx.NodeLookup.TryGetValue(scope, out var node))
                        node.Comment = comment;
                    else warnings.Add($"Comments sheet: unknown node '{scope}'");
                }
                else if (type == "EV")
                {
                    if (ctx.EnvLookup.TryGetValue(scope, out var env))
                        env.Comment = comment;
                    else warnings.Add($"Comments sheet: unknown environment variable '{scope}'");
                }
                else if (type == "GENERIC")
                {
                    // we ignore generic top-level comments for now
                }
                else
                {
                    warnings.Add($"Unknown comment type '{type}' in {SheetName}");
                }
            }
        }
    }
}
