﻿using DbcParserLib.Model;
using System;
using System.Collections.Generic;

namespace ExcelParserLib
{
    internal class ParseContext
    {
        public IList<Node> Nodes { get; } = new List<Node>();
        public IList<Message> Messages { get; } = new List<Message>();
        public IList<EnvironmentVariable> EnvironmentVariables { get; } = new List<EnvironmentVariable>();

        // name -> map
        public IDictionary<string, IReadOnlyDictionary<int, string>> NamedValueTables { get; } = new Dictionary<string, IReadOnlyDictionary<int, string>>(StringComparer.InvariantCultureIgnoreCase);

        // custom property definitions (object type -> (name -> def))
        public IDictionary<DbcParserLib.Model.CustomPropertyObjectType, IDictionary<string, DbcParserLib.Model.CustomPropertyDefinition>> CustomPropertyDefinitions { get; }
            = new Dictionary<DbcParserLib.Model.CustomPropertyObjectType, IDictionary<string, DbcParserLib.Model.CustomPropertyDefinition>>()
            {
                { DbcParserLib.Model.CustomPropertyObjectType.Node, new Dictionary<string, DbcParserLib.Model.CustomPropertyDefinition>() },
                { DbcParserLib.Model.CustomPropertyObjectType.Message, new Dictionary<string, DbcParserLib.Model.CustomPropertyDefinition>() },
                { DbcParserLib.Model.CustomPropertyObjectType.Signal, new Dictionary<string, DbcParserLib.Model.CustomPropertyDefinition>() },
                { DbcParserLib.Model.CustomPropertyObjectType.Environment, new Dictionary<string, DbcParserLib.Model.CustomPropertyDefinition>() },
                { DbcParserLib.Model.CustomPropertyObjectType.Global, new Dictionary<string, DbcParserLib.Model.CustomPropertyDefinition>() },
            };

        // helper lookup maps
        public IDictionary<uint, Message> MessageLookup { get; } = new Dictionary<uint, Message>();
        public IDictionary<string, Node> NodeLookup { get; } = new Dictionary<string, Node>(StringComparer.InvariantCultureIgnoreCase);
        public IDictionary<string, EnvironmentVariable> EnvLookup { get; } = new Dictionary<string, EnvironmentVariable>(StringComparer.InvariantCultureIgnoreCase);
    }
}
