﻿using ClosedXML.Excel;
using DbcParserLib.Model;
using System;
using System.Globalization;

namespace ExcelParserLib
{
    internal class BA_AssignmentsSheetParser : ISheetParser
    {
        private const string SheetName = "BA";

        public void Parse(IXLWorksheet worksheet, ParseContext ctx, IList<string> warnings) { /* unused */ }

        public void Parse(XLWorkbook wb, ParseContext ctx, IList<string> warnings)
        {
            if (!wb.TryGetWorksheet(SheetName, out var ws)) return;

            // This library stores BA_DEF (definitions) with ctx.CustomPropertyDefinitions but does not automatically
            // apply BA (assignment) values to instances (because that requires creating CustomProperty instances for objects).
            // We'll implement a pragmatic behavior:
            // - For BO (message): set CustomProperties map on message if definition exists
            // - For BU (node): set CustomProperties on node
            // - For SG (signal) and EV similar
            //
            // Column layout: Scope, ScopeIdentifier, AttributeName, Value

            foreach (var row in ws.RowsUsed().Skip(1))
            {
                var scope = row.Cell(1).GetString().Trim().ToUpperInvariant();
                var scopeId = row.Cell(2).GetString().Trim();
                var attrName = row.Cell(3).GetString().Trim();
                var valueRaw = row.Cell(4).GetString();

                if (string.IsNullOrWhiteSpace(attrName))
                {
                    warnings.Add($"BA row with empty AttributeName in {SheetName}");
                    continue;
                }

                if (scope == "GLOBAL")
                {
                    // convert to a CustomProperty instance? We skip global instantiation here (writer will read CustomProperty objects from Dbc.GlobalProperties)
                    warnings.Add($"BA GLOBAL assignment for '{attrName}' ignored by simple importer. Consider post-processing.");
                    continue;
                }
                else if (scope == "BU")
                {
                    if (!ctx.NodeLookup.TryGetValue(scopeId, out var node))
                    {
                        warnings.Add($"BA assignment references unknown node '{scopeId}'");
                        continue;
                    }
                    // create CustomProperty instance if definition exists
                    if (ctx.CustomPropertyDefinitions.TryGetValue(CustomPropertyObjectType.Node, out var defs) && defs.TryGetValue(attrName, out var def))
                    {
                        var cp = new DbcParserLib.Model.CustomProperty(def);
                        if (!cp.SetCustomPropertyValue(valueRaw.Replace("\"", ""), !valueRaw.StartsWith("\"")))
                            warnings.Add($"BA assignment value '{valueRaw}' invalid for property '{attrName}' on node '{scopeId}'");
                        else
                            node.CustomProperties[attrName] = cp;
                    }
                    else
                    {
                        warnings.Add($"BA assignment references undefined property '{attrName}' for node '{scopeId}'");
                    }
                }
                else if (scope == "BO")
                {
                    if (!ExcelHelpers.TryParseId(scopeId, out var mid) || !ctx.MessageLookup.TryGetValue(mid, out var msg))
                    {
                        warnings.Add($"BA assignment references unknown message '{scopeId}'");
                        continue;
                    }
                    if (ctx.CustomPropertyDefinitions.TryGetValue(CustomPropertyObjectType.Message, out var defs) && defs.TryGetValue(attrName, out var def))
                    {
                        var cp = new DbcParserLib.Model.CustomProperty(def);
                        if (!cp.SetCustomPropertyValue(valueRaw.Replace("\"", ""), !valueRaw.StartsWith("\"")))
                            warnings.Add($"BA assignment value '{valueRaw}' invalid for property '{attrName}' on message '{scopeId}'");
                        else
                            msg.CustomProperties[attrName] = cp;
                    }
                    else
                        warnings.Add($"BA assignment references undefined message property '{attrName}' for message '{scopeId}'");
                }
                else if (scope == "SG")
                {
                    // scopeId is expected "messageId:signalName"
                    var parts = scopeId.Split(':');
                    if (parts.Length != 2 || !ExcelHelpers.TryParseId(parts[0], out var mid) || !ctx.MessageLookup.TryGetValue(mid, out var msg))
                    {
                        warnings.Add($"BA assignment references unknown signal scope '{scopeId}'");
                        continue;
                    }
                    var sigName = parts[1];
                    var sig = msg.Signals.Find(s => s.Name == sigName);
                    if (sig == null) { warnings.Add($"Signal '{sigName}' not found in message {mid} for BA assignment"); continue; }

                    if (ctx.CustomPropertyDefinitions.TryGetValue(CustomPropertyObjectType.Signal, out var defs) && defs.TryGetValue(attrName, out var def))
                    {
                        var cp = new DbcParserLib.Model.CustomProperty(def);
                        if (!cp.SetCustomPropertyValue(valueRaw.Replace("\"", ""), !valueRaw.StartsWith("\"")))
                            warnings.Add($"BA assignment value '{valueRaw}' invalid for property '{attrName}' on signal '{sigName}'");
                        else
                            sig.CustomProperties[attrName] = cp;
                    }
                    else
                        warnings.Add($"BA assignment references undefined signal property '{attrName}' for '{scopeId}'");
                }
                else if (scope == "EV")
                {
                    if (!ctx.EnvLookup.TryGetValue(scopeId, out var env)) { warnings.Add($"BA assignment references unknown environment variable '{scopeId}'"); continue; }
                    if (ctx.CustomPropertyDefinitions.TryGetValue(CustomPropertyObjectType.Environment, out var defs) && defs.TryGetValue(attrName, out var def))
                    {
                        var cp = new DbcParserLib.Model.CustomProperty(def);
                        if (!cp.SetCustomPropertyValue(valueRaw.Replace("\"", ""), !valueRaw.StartsWith("\"")))
                            warnings.Add($"BA assignment value '{valueRaw}' invalid for property '{attrName}' on env var '{scopeId}'");
                        else
                            env.CustomProperties[attrName] = cp;
                    }
                    else
                        warnings.Add($"BA assignment references undefined env property '{attrName}' for '{scopeId}'");
                }
                else
                {
                    warnings.Add($"Unknown BA scope '{scope}' in sheet {SheetName}");
                }
            }
        }
    }
}
