﻿using ClosedXML.Excel;
using System.Collections.Generic;

namespace ExcelParserLib
{
    internal interface ISheetParser
    {
        /// <summary>
        /// Parse the workbook (parser will locate its own sheet by name).
        /// Implementations mutate the shared ParseContext and append warnings.
        /// </summary>
        void Parse(XLWorkbook workbook, ParseContext ctx, IList<string> warnings);
    }
}
