﻿using ClosedXML.Excel;
using System;
using System.Linq;

namespace ExcelParserLib
{
    internal class ExtraTransmittersSheetParser : ISheetParser
    {
        private const string SheetName = "ExtraTransmitters";

        public void Parse(IXLWorksheet worksheet, ParseContext ctx, IList<string> warnings) { /* unused */ }

        public void Parse(XLWorkbook wb, ParseContext ctx, IList<string> warnings)
        {
            if (!wb.TryGetWorksheet(SheetName, out var ws)) return;

            foreach (var row in ws.RowsUsed().Skip(1))
            {
                var idRaw = row.Cell(1).GetString().Trim();
                if (!ExcelHelpers.TryParseId(idRaw, out var id))
                {
                    warnings.Add($"Invalid MessageID '{idRaw}' in {SheetName}");
                    continue;
                }
                if (!ctx.MessageLookup.TryGetValue(id, out var msg))
                {
                    warnings.Add($"ExtraTransmitters references unknown message {id}");
                    continue;
                }

                var txsRaw = row.Cell(2).GetString();
                if (string.IsNullOrWhiteSpace(txsRaw)) continue;
                var txs = txsRaw.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim()).ToArray();
                msg.AdditionalTransmitters = txs;
            }
        }
    }
}
