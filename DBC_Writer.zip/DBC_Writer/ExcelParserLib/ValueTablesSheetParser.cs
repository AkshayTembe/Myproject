﻿using ClosedXML.Excel;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace ExcelParserLib
{
    internal class ValueTablesSheetParser : ISheetParser
    {
        private const string SheetName = "ValueTables";
        private static readonly Regex PairRegex = new Regex(@"(-?\d+)\s*:\s*""([^""]*)""", RegexOptions.Compiled);

        public void Parse(IXLWorksheet worksheet, ParseContext ctx, IList<string> warnings) { /* not used */ }

        public void Parse(XLWorkbook wb, ParseContext ctx, IList<string> warnings)
        {
            if (!wb.TryGetWorksheet(SheetName, out var ws)) return;

            foreach (var row in ws.RowsUsed().Skip(1))
            {
                var tableName = row.Cell(1).GetString().Trim();
                var entries = row.Cell(2).GetString().Trim();
                if (string.IsNullOrWhiteSpace(tableName)) continue;
                if (string.IsNullOrWhiteSpace(entries))
                {
                    warnings.Add($"Empty entries for value table '{tableName}'");
                    continue;
                }

                var dict = new Dictionary<int, string>();
                var matches = PairRegex.Matches(entries);
                foreach (Match m in matches)
                {
                    if (int.TryParse(m.Groups[1].Value, out var key))
                        dict[key] = m.Groups[2].Value;
                }

                if (dict.Count == 0)
                    warnings.Add($"No valid pairs parsed for value table '{tableName}'");
                else
                    ctx.NamedValueTables[tableName] = dict;
            }
        }
    }
}
