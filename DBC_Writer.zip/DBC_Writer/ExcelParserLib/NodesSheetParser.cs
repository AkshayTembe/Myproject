﻿using ClosedXML.Excel;
using DbcParserLib.Model;
using System.Collections.Generic;

namespace ExcelParserLib
{
    internal class NodesSheetParser : ISheetParser
    {
        private const string SheetName = "Nodes";

        public void Parse(IXLWorksheet worksheet, ParseContext ctx, IList<string> warnings)
        {
            if (worksheet == null) return;
            // Not used. Keep for signature conformance.
        }

        // overload called by ExcelParser extension
        public void Parse(XLWorkbook wb, ParseContext ctx, IList<string> warnings)
        {
            if (!wb.TryGetWorksheet(SheetName, out var ws)) return;

            foreach (var row in ws.RowsUsed().Skip(1))
            {
                var name = row.Cell(1).GetString().Trim();
                if (string.IsNullOrWhiteSpace(name)) continue;
                if (ctx.NodeLookup.ContainsKey(name))
                {
                    warnings.Add($"Duplicate node '{name}' in sheet {SheetName}");
                    continue;
                }
                var node = new Node { Name = name };
                ctx.Nodes.Add(node);
                ctx.NodeLookup[name] = node;
            }
        }
    }
}
