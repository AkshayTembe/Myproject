﻿using ClosedXML.Excel;
using DbcParserLib.Model;
using System;
using System.Collections.Generic;

namespace ExcelParserLib
{
    internal class EnvironmentVariablesSheetParser : ISheetParser
    {
        private const string SheetName = "EnvironmentVariables";

        public void Parse(IXLWorksheet worksheet, ParseContext ctx, IList<string> warnings) { /* unused */ }

        public void Parse(XLWorkbook wb, ParseContext ctx, IList<string> warnings)
        {
            if (!wb.TryGetWorksheet(SheetName, out var ws)) return;

            foreach (var row in ws.RowsUsed().Skip(1))
            {
                var name = row.Cell(1).GetString().Trim();
                if (string.IsNullOrWhiteSpace(name)) continue;

                var type = row.Cell(2).GetString().Trim().ToUpperInvariant();
                var env = new EnvironmentVariable { Name = name, Unit = row.Cell(6).GetString() };

                switch (type)
                {
                    case "INT":
                        env.Type = EnvDataType.Integer;
                        env.IntegerEnvironmentVariable = new NumericEnvironmentVariable<int>
                        {
                            Minimum = row.Cell(3).GetValue<int>(),
                            Maximum = row.Cell(4).GetValue<int>(),
                            Default = row.Cell(5).GetValue<int>()
                        };
                        break;
                    case "FLOAT":
                        env.Type = EnvDataType.Float;
                        env.FloatEnvironmentVariable = new NumericEnvironmentVariable<double>
                        {
                            Minimum = row.Cell(3).GetDouble(),
                            Maximum = row.Cell(4).GetDouble(),
                            Default = row.Cell(5).GetDouble()
                        };
                        break;
                    case "STRING":
                        env.Type = EnvDataType.String;
                        break;
                    case "DATA":
                        env.Type = EnvDataType.Data;
                        env.DataEnvironmentVariable = new DataEnvironmentVariable { Length = (uint)row.Cell(8).GetValue<int>() };
                        break;
                    default:
                        warnings.Add($"Unknown env var type '{type}' for '{name}' in {SheetName}");
                        break;
                }

                // nodes owning variable (optional)
                var nodesCell = row.Cell(7).GetString();
                if (!string.IsNullOrWhiteSpace(nodesCell))
                {
                    var nodes = nodesCell.Split(new[] { ',', ';' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var n in nodes)
                    {
                        var nm = n.Trim();
                        if (ctx.NodeLookup.TryGetValue(nm, out var node))
                        {
                            node.EnvironmentVariables[nm] = env;
                        }
                        else
                        {
                            warnings.Add($"Unknown node '{nm}' referenced for env var '{name}'");
                        }
                    }
                }

                ctx.EnvironmentVariables.Add(env);
                ctx.EnvLookup[name] = env;
            }
        }
    }
}
