﻿using DbcParserLib.Model;
using System;
using System.Globalization;
using System.Linq;

namespace ExcelParserLib
{
    internal static class ExcelHelpers
    {
        public static bool TryParseId(string s, out uint id)
        {
            id = 0;
            if (string.IsNullOrWhiteSpace(s)) return false;
            s = s.Trim();
            if (s.StartsWith("0x", StringComparison.InvariantCultureIgnoreCase))
            {
                return uint.TryParse(s.Substring(2), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out id);
            }
            return uint.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out id);
        }

        public static CustomPropertyDefinition BuildCustomPropertyDefinition(string name, string type, string min, string max, string enumValues, out string error)
        {
            error = null;
            try
            {
                var def = new CustomPropertyDefinition(null) { Name = name };

                if (string.Equals(type, "INT", StringComparison.InvariantCultureIgnoreCase))
                {
                    def.DataType = CustomPropertyDataType.Integer;
                    def.IntegerCustomProperty = new NumericCustomPropertyDefinition<int>
                    {
                        Minimum = int.Parse(min),
                        Maximum = int.Parse(max)
                    };
                }
                else if (string.Equals(type, "HEX", StringComparison.InvariantCultureIgnoreCase))
                {
                    def.DataType = CustomPropertyDataType.Hex;
                    def.HexCustomProperty = new NumericCustomPropertyDefinition<int>
                    {
                        Minimum = int.Parse(min, CultureInfo.InvariantCulture),
                        Maximum = int.Parse(max, CultureInfo.InvariantCulture)
                    };
                }
                else if (string.Equals(type, "FLOAT", StringComparison.InvariantCultureIgnoreCase))
                {
                    def.DataType = CustomPropertyDataType.Float;
                    def.FloatCustomProperty = new NumericCustomPropertyDefinition<double>
                    {
                        Minimum = double.Parse(min, CultureInfo.InvariantCulture),
                        Maximum = double.Parse(max, CultureInfo.InvariantCulture)
                    };
                }
                else if (string.Equals(type, "STRING", StringComparison.InvariantCultureIgnoreCase))
                {
                    def.DataType = CustomPropertyDataType.String;
                    def.StringCustomProperty = new StringCustomPropertyDefinition();
                }
                else if (string.Equals(type, "ENUM", StringComparison.InvariantCultureIgnoreCase))
                {
                    def.DataType = CustomPropertyDataType.Enum;
                    var arr = (enumValues ?? string.Empty).Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim().Trim('"')).ToArray();
                    def.EnumCustomProperty = new EnumCustomPropertyDefinition { Values = arr };
                }
                else
                {
                    error = $"Unknown type {type}";
                    return null;
                }

                return def;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return null;
            }
        }
    }
}
