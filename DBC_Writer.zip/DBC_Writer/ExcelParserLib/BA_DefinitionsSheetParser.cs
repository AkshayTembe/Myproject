﻿using ClosedXML.Excel;
using DbcParserLib.Model;
using System;
using System.Globalization;
using System.Linq;

namespace ExcelParserLib
{
    internal class BA_DefinitionsSheetParser : ISheetParser
    {
        private const string SheetName = "BA_DEF";

        public void Parse(IXLWorksheet worksheet, ParseContext ctx, IList<string> warnings) { /* unused */ }

        public void Parse(XLWorkbook wb, ParseContext ctx, IList<string> warnings)
        {
            if (!wb.TryGetWorksheet(SheetName, out var ws)) return;

            foreach (var row in ws.RowsUsed().Skip(1))
            {
                var scope = row.Cell(1).GetString().Trim().ToUpperInvariant();
                var name = row.Cell(2).GetString().Trim();
                var type = row.Cell(3).GetString().Trim().ToUpperInvariant();
                var min = row.Cell(4).GetString();
                var max = row.Cell(5).GetString();
                var enumVals = row.Cell(6).GetString();

                if (string.IsNullOrWhiteSpace(name)) { warnings.Add("BA_DEF with empty name"); continue; }

                var def = ExcelHelpers.BuildCustomPropertyDefinition(name, type, min, max, enumVals, out var err);
                if (def == null) { warnings.Add($"BA_DEF '{name}' parse error: {err}"); continue; }

                var objType = CustomPropertyObjectType.Global;
                if (scope == "NODE") objType = CustomPropertyObjectType.Node;
                else if (scope == "MESSAGE") objType = CustomPropertyObjectType.Message;
                else if (scope == "SIGNAL") objType = CustomPropertyObjectType.Signal;
                else if (scope == "ENV") objType = CustomPropertyObjectType.Environment;

                ctx.CustomPropertyDefinitions[objType][name] = def;
            }
        }
    }
}
