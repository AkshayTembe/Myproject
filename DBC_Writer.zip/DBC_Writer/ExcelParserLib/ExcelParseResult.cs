﻿using DbcParserLib;
using System.Collections.Generic;

namespace ExcelParserLib
{
    public class ExcelParseResult
    {
        public Dbc Dbc { get; }
        public IReadOnlyList<string> Warnings { get; }

        public ExcelParseResult(Dbc dbc, IReadOnlyList<string> warnings)
        {
            Dbc = dbc;
            Warnings = warnings;
        }
    }
}
