﻿using ClosedXML.Excel;
using DbcParserLib.Model;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace ExcelParserLib
{
    internal class MessagesSheetParser : ISheetParser
    {
        private const string SheetName = "Messages";

        public void Parse(IXLWorksheet worksheet, ParseContext ctx, IList<string> warnings) { /* unused */ }

        public void Parse(XLWorkbook wb, ParseContext ctx, IList<string> warnings)
        {
            if (!wb.TryGetWorksheet(SheetName, out var ws)) return;

            foreach (var row in ws.RowsUsed().Skip(1))
            {
                var idRaw = row.Cell(1).GetString().Trim();
                if (!ExcelHelpers.TryParseId(idRaw, out var id))
                {
                    warnings.Add($"Invalid message ID '{idRaw}' in {SheetName}");
                    continue;
                }

                if (ctx.MessageLookup.ContainsKey(id))
                {
                    warnings.Add($"Duplicate message ID {id} in {SheetName}");
                    continue;
                }

                var name = row.Cell(2).GetString().Trim();
                if (string.IsNullOrWhiteSpace(name))
                {
                    warnings.Add($"Empty message name for ID {id} in {SheetName}");
                    name = $"MSG_{id}";
                }

                ushort dlc = 8;
                try { dlc = (ushort)row.Cell(3).GetValue<int>(); } catch { /* default 8 */ }

                var tx = row.Cell(4).GetString().Trim();
                var isExtStr = row.Cell(5).GetString().Trim();
                bool isExt = false; bool.TryParse(isExtStr, out isExt);
                var comment = row.Cell(6).GetString();

                var msg = new Message
                {
                    ID = id,
                    Name = name,
                    DLC = dlc,
                    Transmitter = tx ?? string.Empty,
                    IsExtID = isExt,
                    Comment = string.IsNullOrWhiteSpace(comment) ? null : comment
                };

                ctx.Messages.Add(msg);
                ctx.MessageLookup[id] = msg;
            }
        }
    }
}
