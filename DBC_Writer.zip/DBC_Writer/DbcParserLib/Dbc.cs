// Dbc.cs
using System.Collections.Generic;
using DbcParserLib.Model;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("DbcParserLib.Tests")]
[assembly: InternalsVisibleTo("DynamicProxyGenAssembly2")]
namespace DbcParserLib
{
    public class Dbc
    {
        public IEnumerable<Node> Nodes { get; }
        public IEnumerable<Message> Messages { get; }
        public IEnumerable<EnvironmentVariable> EnvironmentVariables { get; }
        public IEnumerable<CustomProperty> GlobalProperties { get; }

        // Newly exposed:
        // Named value tables (VAL_TABLE_ <name> ... )
        public IReadOnlyDictionary<string, IReadOnlyDictionary<int, string>> NamedValueTables { get; }

        // Custom property definitions grouped by object type (BA_DEF_). Each inner dictionary maps property name -> definition
        public IReadOnlyDictionary<Model.CustomPropertyObjectType, IReadOnlyDictionary<string, Model.CustomPropertyDefinition>> CustomPropertyDefinitions { get; }

        public Dbc(
            IEnumerable<Node> nodes,
            IEnumerable<Message> messages,
            IEnumerable<EnvironmentVariable> environmentVariables,
            IEnumerable<CustomProperty> globalProperties,
            IReadOnlyDictionary<string, IReadOnlyDictionary<int, string>> namedValueTables,
            IReadOnlyDictionary<Model.CustomPropertyObjectType, IReadOnlyDictionary<string, Model.CustomPropertyDefinition>> customPropertyDefinitions)
        {
            Nodes = nodes;
            Messages = messages;
            EnvironmentVariables = environmentVariables;
            GlobalProperties = globalProperties;
            NamedValueTables = namedValueTables;
            CustomPropertyDefinitions = customPropertyDefinitions;
        }
    }
}
